#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAXTAM 100

typedef struct Deque {
	int inicio;
	int fim;
	int qtd;
	char dados[MAXTAM];
}Deque;

int vazia(Deque deque) {
	if (deque.qtd == 0) {
		printf("Deque vazia\n");
		return 1;
	}
	return 0;
}

int cheia(Deque deque) {
	if (deque.qtd == MAXTAM) {
		printf("Cheia\n");
		return 1;
	}
	return 0;
}
void criar(Deque* deque) {
	deque->inicio = deque->fim = deque->qtd = 0;
}

void inseririnicio(int elemento, Deque* deque) {
	if (!cheia(*deque)) {
		if (deque->qtd == 0) {
			deque->fim = (deque->fim + 1) % MAXTAM;
		}
		else {
			deque->inicio--;
			if (deque->inicio < 0) {
				deque->inicio = MAXTAM - 1;
			}
			deque->dados[deque->inicio] = elemento;
			deque->qtd++;
		}
	}
}

int removerinicio(Deque* deque) {
	int elemento;
	if (!vazia(*deque)) {
		elemento = deque->dados[deque->inicio];
		deque->inicio = (deque->inicio + 1) % MAXTAM;
		deque->qtd--;
		return elemento;
	}
	return -1;
}

int inserirfim(int elemento, Deque* deque) {
	if (cheia(*deque)) {
		printf("Deque cheia");
	}
	else {
		deque->dados[deque->fim] = elemento;
		deque->fim = (deque->fim + 1) % MAXTAM;
		deque->qtd++;
	}
	return -1;
}

int removerfim(Deque* deque) {
	int elemento;
	if (!vazia(*deque)) {
		deque->fim--;
		if (deque->fim < 0) {
			deque->fim = MAXTAM - 1;
		}
		elemento = deque->dados[deque->fim];
		deque->qtd--;
		return elemento;
	}
}

int acessarinicio(Deque deque) {
	if (vazia(deque)) {
		printf("Vazia\n");
		return 1;
	}
	else {
		return deque.dados[deque.inicio];
	}
}

int acessarfim(Deque deque) {
	int pos;
	if (vazia(deque)) {
		printf("Deque Vazia");
		return -1;
	}
	else {
		pos = deque.fim - 1;
		if (pos < 0) {
			pos = MAXTAM - 1;
		}
		return deque.dados[pos];
	}
}

void listar(Deque d) {
	Deque copia;
	criar(&copia);
	int i, pos = d.inicio;
	for (i = 0; i < d.qtd; i++) {
		copia.dados[i] = d.dados[pos];
		pos = (pos + 1) % MAXTAM;
	}
	copia.inicio = 0;
	copia.fim = d.qtd;
	copia.qtd = d.qtd;
	printf("Elemento do deque:\n");
	while (!vazia(copia)) {
		int valor = removerinicio(&copia);
		printf("%d", valor);
	}
	printf("\n");
}

void destruir(Deque* deque) {
	deque->inicio = deque->fim = deque->qtd = 0;
}

int main() {
	Deque d;
	criar(&d);
	int opcao, valor;
	do {
		printf("MENU DEQUE\n");
		printf("1- Inserir Inicio\n");
		printf("2- Inserir Fim\n");
		printf("3- Remover Inicio\n");
		printf("4- Remover Fim\n");
		printf("5- Acessar Inicio\n");
		printf("6- Acessar Fim\n");
		printf("7- Destruir Deque\n");
		printf("8- Listar Elementos\n");
		printf("9-SAIR\n");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Digite o valor para inserir no inicio:\n");
			scanf_s("%d", &valor);
			inseririnicio(valor, &d);
			break;
		case 2:
			printf("Digite o valor para inserir no fim:\n");
			scanf_s("%d", &valor);
			inserirfim(valor, &d);
			break;
		case 3:
			valor = removerinicio(&d);
			if (valor != -1)
				printf("Removido no incio %d\n", valor);
			break;
		case 4:
			valor = removerfim(&d);
			if (valor != -1)
				printf("Removido no fim %d\n", valor);
			break;
		case 5:
			valor = acessarinicio(d);
			if (!vazia(d))
				printf("Incio do deque %d\n", valor);
			break;
		case 6:
			valor = acessarfim(d);
			if (!vazia(d))
				printf("Fim do deque %d\n", valor);
			break;
		case 7:
			destruir(&d);
			printf("Deque destruido\n");
			break;
		case 8:
			listar(d);
			break;
		case 9:
			printf("SAIR\n");
			break;
		default:
			printf("INVALIDO\n");

		}

	} while (opcao != 9);
	return 0;
}