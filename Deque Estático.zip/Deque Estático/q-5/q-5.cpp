#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXTAM 100

typedef struct Solicitacao {
	int id;
	char ip[20];
} Solicitacao;

typedef struct Deque {
	int inicio;
	int fim;
	int qtd;
	Solicitacao dados[MAXTAM];
} Deque;

void criar(Deque* deque) {
	deque->inicio = deque->fim = deque->qtd = 0;
}

int cheia(Deque* deque) {
	if (deque->qtd == MAXTAM) {
		printf("Cheia\n");
		return 1;
	}
	return 0;
}

int vazia(Deque* deque) {
	if (deque->qtd == 0) {
		printf("Vazia\n");
		return 1;
	}
	return 0;
}

void inseririnicio(Solicitacao solicitacao, Deque* deque) {
	if (!cheia(deque)) {
		if (deque->qtd == 0) {
			deque->fim = (deque->fim + 1) % MAXTAM;
		}
		else {
			deque->inicio--;
			if (deque->inicio < 0) deque->inicio = MAXTAM - 1;
		}
		deque->dados[deque->inicio] = solicitacao;
		deque->qtd++;
	}
}

void inserirfim(Solicitacao solicitacao, Deque* deque) {
	if (cheia(deque)) {
		printf("Cheia\n");
	}
	else {
		deque->dados[deque->fim] = solicitacao;
		deque->fim = (deque->fim + 1) % MAXTAM;
		deque->qtd++;
	}
}

Solicitacao removerinicio(Deque* deque) {
	Solicitacao elemento;
	if (!vazia(deque)) {
		elemento = deque->dados[deque->inicio];
		deque->inicio = (deque->inicio + 1) % MAXTAM;
		deque->qtd--;
		return elemento;
	}
	elemento.id = -1;
	strcpy_s(elemento.ip, "");
	return elemento;
}

void listar(Deque deque) {
	Deque copia;
	criar(&copia);
	int i, pos = deque.inicio;
	for (i = 0; i < deque.qtd; i++) {
		copia.dados[i] = deque.dados[pos];
		pos = (pos + 1) % MAXTAM;
	}
	copia.inicio = 0;
	copia.fim = deque.qtd;
	copia.qtd = deque.qtd;

	printf("Elementos da deque:\n");
	while (!vazia(&copia)) {
		Solicitacao valor = removerinicio(&copia);
		printf("ID: %d, IP: %s\n", valor.id, valor.ip);
	}
}

int main() {
	Deque fila;
	criar(&fila);
	int opcao;
	Solicitacao solicitacao;

	do {
		printf("\nMENU\n");
		printf("1 - Adicionar Solicitacao (alta prioridade)\n");
		printf("2 - Adicionar Solicitacao (normal prioridade)\n");
		printf("3 - Processar Solicitacao\n");
		printf("4 - Listar Solicitacoes\n");
		printf("5 - Sair\n");
		printf("Opcao: ");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("ID da solicitacao: ");
			scanf_s("%d", &solicitacao.id);
			printf("IP da maquina: ");
			scanf_s("%s", solicitacao.ip, 20);
			inseririnicio(solicitacao, &fila);
			break;
		case 2:
			printf("ID da solicitacao: ");
			scanf_s("%d", &solicitacao.id);
			printf("IP da maquina: ");
			scanf_s("%s", solicitacao.ip, 20);
			inserirfim(solicitacao, &fila);
			break;
		case 3:
			solicitacao = removerinicio(&fila);
			if (solicitacao.id != -1) {
				printf("Processando: ID %d, IP %s\n", solicitacao.id, solicitacao.ip);
			}
			break;
		case 4:
			listar(fila);
			break;
		case 5:
			printf("Encerrando...\n");
			break;
		default:
			printf("Opcao invalida.\n");
		}
	} while (opcao != 5);

	return 0;
}
