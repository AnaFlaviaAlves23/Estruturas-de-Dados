#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAMANHO 10
#define MAX_TEXTO 50

typedef struct {
	char elementos[TAMANHO][MAX_TEXTO];
	int topo;
}Pilha;

Pilha inicializar() {
	Pilha P;
	P.topo = -1;
	return P;
}

int cheia(Pilha P) {
	return P.topo == TAMANHO - 1;
}

int vazia(Pilha P) {
	return P.topo == -1;
}

Pilha empilhar(Pilha P, char elemento[]) {
	if (!cheia(P)) {
		P.topo++;
		strcpy_s(P.elementos[P.topo], elemento);
	}
	else {
		printf("Pilha cheia\n ");
	}
	return P;
}
Pilha desempilhar(Pilha P) {
	if (!vazia(P)) {
		printf("DESFEITO: %s", P.elementos[P.topo]);
		P.topo--;
	}
	else {
		printf("Pilha Vazia \n");
	}
	return P;
}
void mostra(Pilha P) {
	printf("Pilha atual\n");
	int i;
	for (i = 0; i <= P.topo; i++) {
		printf("-%s\n", P.elementos[i]);
	}
}
int main()
{
	Pilha Pilha = inicializar();
	int opcao;
	char texto[MAX_TEXTO];
	do {
		printf("1-Escrever palavra\n");
		printf("2-Desfazer\n");
		printf("3-Exbir\n");
		printf("4-Sair\n");
		scanf_s("%d", &opcao);
		getchar();

		if (opcao == 1) {
			printf("Digite a palavra");
			fgets(texto, MAX_TEXTO, stdin);
			texto[strcspn(texto, "\n")] = '\0';
			Pilha = empilhar(Pilha, texto);
		}
		else if (opcao == 2) {
			printf("Desempilhar\n");
			Pilha = desempilhar(Pilha);
		}
		else if (opcao == 3) {
			mostra(Pilha);
		}
	} while (opcao != 4);
	return 0;
}
