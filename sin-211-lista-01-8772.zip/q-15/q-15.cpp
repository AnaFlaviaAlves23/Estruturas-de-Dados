#include <stdio.h>
#include <stdlib.h>

#define MAX 50

// ------------------- PILHA ---------------------
typedef struct {
    int dados[MAX];
    int topo;
} Pilha;

Pilha inicializarPilha() {
    Pilha P;
    P.topo = -1;
    return P;
}

int pilhaCheia(Pilha P) {
    return P.topo == MAX - 1;
}

int pilhaVazia(Pilha P) {
    return P.topo == -1;
}

Pilha empilhar(Pilha P, int valor) {
    if (!pilhaCheia(P)) {
        P.topo++;
        P.dados[P.topo] = valor;
    }
    else {
        printf("Pilha cheia\n");
    }
    return P;
}

Pilha desempilhar(Pilha P) {
    if (!pilhaVazia(P)) {
        printf("Desempilhado: %d\n", P.dados[P.topo]);
        P.topo--;
    }
    else {
        printf("Pilha vazia\n");
    }
    return P;
}

void mostrarPilha(Pilha P) {
    printf("Pilha atual:\n");
    for (int i = 0; i <= P.topo; i++) {
        printf("%d\n", P.dados[i]);
    }
}

// ------------------- FILA COM PONTEIROS ---------------------
typedef struct {
    int dados[MAX];
    int inicio;
    int fim;
    int qtd;
} Fila;

void inicializarFila(Fila* F) {
    F->inicio = 0;
    F->fim = 0;
    F->qtd = 0;
}

int filaCheia(Fila* F) {
    return F->qtd == MAX;
}

int filaVazia(Fila* F) {
    return F->qtd == 0;
}

void enfileirar(Fila* F, int valor) {
    if (filaCheia(F)) {
        printf("Fila cheia\n");
    }
    else {
        F->dados[F->fim] = valor;
        F->fim = (F->fim + 1) % MAX;
        F->qtd++;
    }
}

int desenfileirar(Fila* F) {
    int valor = -1;
    if (filaVazia(F)) {
        printf("Fila vazia\n");
    }
    else {
        valor = F->dados[F->inicio];
        F->inicio = (F->inicio + 1) % MAX;
        F->qtd--;
    }
    return valor;
}

void mostrarFila(Fila* F) {
    if (filaVazia(F)) {
        printf("Fila vazia\n");
        return;
    }
    printf("Fila atual:\n");
    int i, pos = F->inicio;
    for (i = 0; i < F->qtd; i++) {
        printf("%d ", F->dados[pos]);
        pos = (pos + 1) % MAX;
    }
    printf("\n");
}

// ------------------- MAIN ---------------------
int main() {
    Pilha P = inicializarPilha();
    Fila F;
    inicializarFila(&F);

    int i;

    printf("Empilhando 1, 2, 3 na pilha\n");
    for (i = 1; i <= 3; i++) {
        P = empilhar(P, i);
    }
    mostrarPilha(P);

    printf("\nEnfileirando 1, 2, 3 na fila\n");
    for (i = 1; i <= 3; i++) {
        enfileirar(&F, i);
    }
    mostrarFila(&F);

    printf("\nDesempilhando\n");
    P = desempilhar(P);
    mostrarPilha(P);

    printf("\nDesenfileirando\n");
    int removido = desenfileirar(&F);
    if (removido != -1)
        printf("Removido da fila: %d\n", removido);
    mostrarFila(&F);

    return 0;
}
