#include <stdio.h>

#define MAX 100  


typedef struct
{
    int elementos[MAX];
    int tamanho;
} Conjunto;


void criarConjuntoVazio(Conjunto* c)
{
    c->tamanho = 0;
}

void inserir(Conjunto* c, int valor)
{
    if (c->tamanho < MAX)
    {
        for (int i = 0; i < c->tamanho; i++)
        {
            if (c->elementos[i] == valor)
            {
                return; // N�o insere o mesmo valor duas vezes
            }
        }
        //insere o elemento e aumenta o tamanho do conjunto
        c->elementos[c->tamanho++] = valor;
    }
}

void remover(Conjunto* c, int valor)
{
    for (int i = 0; i < c->tamanho; i++)
    {
        if (c->elementos[i] == valor)
        {
            // retira o elemento do conjunto e diminue seu tamanho
            c->elementos[i] = c->elementos[c->tamanho - 1];
            c->tamanho--;
            return;
        }
    }
}

Conjunto uniao(Conjunto c1, Conjunto c2)
{
    Conjunto uniao;
    criarConjuntoVazio(&uniao);

    //insere as posi��es do primeiro vetor
    for (int i = 0; i < c1.tamanho; i++)
    {
        inserir(&uniao, c1.elementos[i]);
    }

    //insere as posi��es do segundo vetor
    for (int i = 0; i < c2.tamanho; i++)
    {
        inserir(&uniao, c2.elementos[i]);
    }
    return uniao;
}

int pertence(Conjunto c, int valor)
{
    for (int i = 0; i < c.tamanho; i++)
    {
        if (c.elementos[i] == valor)
        {
            return 1;
        }
    }
    return 0;
}


Conjunto intersecao(Conjunto c1, Conjunto c2)
{
    Conjunto intersecao;
    criarConjuntoVazio(&intersecao);

    for (int i = 0; i < c1.tamanho; i++)
    {
        //checa se o elemento de c1 pertence a c2
        if (pertence(c2, c1.elementos[i]))
        {
            inserir(&intersecao, c1.elementos[i]);
        }
    }
    return intersecao;
}

Conjunto diferenca(Conjunto c1, Conjunto c2)
{
    Conjunto diferenca;
    criarConjuntoVazio(&diferenca);

    for (int i = 0; i < c1.tamanho; i++)
    {
        //checa se o c1 n�o pertence a c2 
        if (!pertence(c2, c1.elementos[i]))
        {
            inserir(&diferenca, c1.elementos[i]);
        }
    }

    return diferenca;
}



int menorValor(Conjunto c)
{
    //checa se o conjunto est� vazio
    if (c.tamanho == 0)
    {
        return -1;
    }

    //atribui o valor[0] a menor
    int menor = c.elementos[0];

    for (int i = 1; i < c.tamanho; i++)
    {
        //chaca se o valor de menor � menor que o proximo elemento
        if (c.elementos[i] < menor)
        {
            menor = c.elementos[i];
        }
    }
    return menor;
}

int maiorValor(Conjunto c)
{
    //checa se o conjunto est� vazio
    if (c.tamanho == 0)
    {
        return -1;
    }

    //atribui o valor[0] a maior
    int maior = c.elementos[0];

    for (int i = 1; i < c.tamanho; i++)
    {
        //chaca se o valor de maior � maior que o proximo elemento
        if (c.elementos[i] > maior)
        {
            maior = c.elementos[i];
        }
    }
    return maior;
}

int saoIguais(Conjunto c1, Conjunto c2)
{
    //checa se o tamanho dos conjuntos � igual, se n�o eles s�o diferentes
    if (c1.tamanho != c2.tamanho)
    {
        return 0;
    }
    for (int i = 0; i < c1.tamanho; i++)
    {
        //checa se qualquer posi��o dos conjuntos � diferente. Pertence == 0
        if (!pertence(c2, c1.elementos[i]))
        {
            return 0;
        }
    }

    return 1;
}

int tamanho(Conjunto c)
{
    return c.tamanho;
}

int conjuntoVazio(Conjunto c)
{
    return c.tamanho == 0;
}


void exibirConjunto(Conjunto c)
{
    printf("{ ");
    //for q serve para percorrer o conjunto todo
    for (int i = 0; i < c.tamanho; i++)
    {
        printf("%d ", c.elementos[i]);
    }
    printf("}\n");
}


int main()
{
    Conjunto A, B, C;

    criarConjuntoVazio(&A);
    criarConjuntoVazio(&B);

    inserir(&A, 1);
    inserir(&A, 3);
    inserir(&A, 5);

    inserir(&B, 3);
    inserir(&B, 4);
    inserir(&B, 5);

    printf("Conjunto A: ");
    exibirConjunto(A);
    printf("Conjunto B: ");
    exibirConjunto(B);

    C = uniao(A, B);
    printf("Uniao: ");
    exibirConjunto(C);

    C = intersecao(A, B);
    printf("Intersecao: ");
    exibirConjunto(C);

    C = diferenca(A, B);
    printf("Diferenca A - B: ");
    exibirConjunto(C);

    printf("Menor valor em A: %d\n", menorValor(A));

    printf("Maior valor em B: %d\n", maiorValor(B));

    printf("Tamanho de A: %d\n", tamanho(A));

    //muda o valor a ser printado dependendo do retorno de conjuntovazio
    printf("A e vazio? %s\n", conjuntoVazio(A) ? "Sim" : "Nao");

    return 0;
}
