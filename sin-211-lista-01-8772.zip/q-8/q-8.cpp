#include <stdio.h>
#include <stdlib.h>

#define MAXIMO 20

typedef struct sPilha {
    int dados[MAXIMO];
    int topo;
} Pilha;

Pilha inicializar() {
    Pilha P;
    P.topo = -1;
    return P;
}

int cheia(Pilha P) {
    return P.topo == MAXIMO - 1;
}

int vazia(Pilha P) {
    return P.topo == -1;
}

Pilha empilhar(Pilha P, int valor) {
    if (!cheia(P)) {
        P.topo++;
        P.dados[P.topo] = valor;
        printf("Inserido: %d\n", valor);
    }
    else {
        printf("Pilha cheia\n");
    }
    return P;
}

Pilha desempilhar(Pilha P) {
    if (!vazia(P)) {
        printf("Removido: %d\n", P.dados[P.topo]);
        P.topo--;
    }
    else {
        printf("Pilha vazia\n");
    }
    return P;
}

int main() {
    Pilha P = inicializar();

    P = empilhar(P, 1);       
    P = empilhar(P, 2);       
    P = desempilhar(P);       
    P = empilhar(P, 3);       
    P = empilhar(P, 4);       
    P = desempilhar(P);       
    P = desempilhar(P);       
    P = desempilhar(P);       

    return 0;
}
