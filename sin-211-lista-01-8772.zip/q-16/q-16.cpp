#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

typedef struct sCliente {
    char nome[50];
    int numconta;
    float saldo;
} Cliente;

typedef struct sFila {
    int inicio;
    int fim;
    int qtd;
    Cliente dados[MAX];
} Fila;

void criar(Fila* fila) {
    fila->inicio = fila->fim = fila->qtd = 0;
}

void destruir(Fila* fila) {
    fila->inicio = fila->fim = fila->qtd = 0;
}

int cheia(Fila fila) {
    return fila.qtd == MAX;
}

int vazia(Fila fila) {
    return fila.qtd == 0;
}

void enfilerar(Cliente cliente, Fila* fila) {
    if (cheia(*fila)) {
        printf("Fila cheia\n");
    }
    else {
        fila->dados[fila->fim] = cliente;
        fila->fim = (fila->fim + 1) % MAX;
        fila->qtd++;
    }
}

int desenfilerar(Cliente* cliente, Fila* fila) {
    if (vazia(*fila)) {
        printf("Fila vazia\n");
        return 0;
    }
    else {
        *cliente = fila->dados[fila->inicio];
        fila->inicio = (fila->inicio + 1) % MAX;
        fila->qtd--;
        return 1;
    }
}

void exibir(Fila fila) {
    int i, pos;
    if (vazia(fila)) {
        printf("\nFila vazia!\n");
        return;
    }

    printf("\nClientes na fila:\n");
    for (i = 0; i < fila.qtd; i++) {
        pos = (fila.inicio + i) % MAX;
        printf("\nNumero Conta: %d", fila.dados[pos].numconta);
        printf("\nNome: %s", fila.dados[pos].nome);
        printf("Saldo: %.2f\n", fila.dados[pos].saldo);
    }
}

int main() {
    Fila filaBanco;
    Cliente aux;
    int opcao;

    do {
        printf("\n=== Menu Fila de Clientes ===\n");
        printf("1 - Criar fila\n");
        printf("2 - Destruir fila\n");
        printf("3 - Enfileirar Cliente\n");
        printf("4 - Desenfileirar Cliente\n");
        printf("5 - Exibir fila\n");
        printf("0 - Sair\n");
        printf("Escolha: ");
        scanf_s("%d", &opcao);
        getchar(); 

        switch (opcao) {
        case 1:
            criar(&filaBanco);
            printf("Fila criada!\n");
            break;
        case 2:
            destruir(&filaBanco);
            printf("Fila destru�da!\n");
            break;
        case 3:
            printf("N�mero da conta: ");
            scanf_s("%d", &aux.numconta);
            getchar();

            printf("Nome do cliente: ");
            fgets(aux.nome, sizeof(aux.nome), stdin);
            aux.nome[strcspn(aux.nome, "\n")] = '\0'; 

            printf("Saldo da conta: ");
            scanf_s("%f", &aux.saldo);

            enfilerar(aux, &filaBanco);
            break;
        case 4:
            if (desenfilerar(&aux, &filaBanco)) {
                printf("\nCliente removido:\n");
                printf("Numero Conta: %d\n", aux.numconta);
                printf("Nome: %s\n", aux.nome);
                printf("Saldo: %.2f\n", aux.saldo);
            }
            break;
        case 5:
            exibir(filaBanco);
            break;
        case 0:
            printf("\nTchau! Obrigado por usar o sistema.\n");
            break;
        default:
            printf("Op��o inv�lida!\n");
        }
    } while (opcao != 0);

    return 0;
}
