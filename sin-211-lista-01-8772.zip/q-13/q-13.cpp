#include<stdio.h>
#include<stdlib.h>

#define MAX 50

typedef struct sPilha {
	int dados[MAX];
	int topo;
}Pilha;

Pilha inicializar() {
	Pilha P;
	P.topo = -1;
	return P;
}

int cheia(Pilha P) {
	return P.topo == MAX - 1;
}

int vazia(Pilha P) {
	return P.topo == -1;
}

Pilha empilhar(Pilha P, int valor) {
	if (!cheia(P)) {
		P.topo++;
		P.dados[P.topo] = valor;
	}
	else {
		printf("Pilha cheia\n");
	}
	return P;
}

/*/Pilha desempilhar(Pilha P) {
	if (!vazia(P)) {
		printf("DESEMPILHADO %d \n", P.dados[P.topo]);
		P.topo--;
	}
	else {
		printf("Pilha Vazia \n");
	}
	return P;
}*/

int comparar(Pilha P1, Pilha P2) {
	if (P1.topo > P2.topo) {
		return 1;
	}
	else {
		return 0;
	}
}

int main() {
	Pilha P1 = inicializar();
	Pilha P2 = inicializar();
	int i, quantidade, valor;
	printf("Digite quantos elementos deseja empilhar na pilha\n");
	scanf_s("%d", &quantidade);
	for (i = 0; i < quantidade; i++) {
		printf("Digite o valor %d da pilha P1\n", i + 1);
		scanf_s("%d", &valor);
		P1 = empilhar(P1, valor);
	}
	printf("Digite quantos elementos deseja empilhar na pilha 2\n");
	scanf_s("%d", &quantidade);
	for (i = 0; i < quantidade; i++) {
		printf("Digite o valor %d da pilha P2\n", i + 1);
		scanf_s("%d", &valor);
		P2 = empilhar(P2, valor);
	}
	if (comparar(P1, P2)) {
		printf("A pilha P1 tem mais elementos.\n");
	}
	else {
		printf("A pilha P2 tem igual ou mais elementos.\n");
	}
	return 0;
}