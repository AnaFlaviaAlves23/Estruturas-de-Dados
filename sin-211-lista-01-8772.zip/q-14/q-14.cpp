#include<stdio.h>
#include<stdlib.h>

#define MAX 50

typedef struct sPilha {
	int dados[MAX];
	int topo;
}Pilha;

Pilha inicializar() {
	Pilha P;
	P.topo = -1;
	return P;
}

int cheia(Pilha P) {
	return P.topo == MAX -1;
}

int vazia(Pilha P) {
	return P.topo == -1;
}

Pilha empilhar(Pilha P, int valor) {
	if (!cheia(P)) {
		P.topo++;
		P.dados[P.topo] = valor;
	}
	else {
		printf("Pilha cheia \n");
	}
	return P;
}

Pilha desempilhar(Pilha P) {
	if (!vazia(P)) {
		printf("DESEMPILHADA: %d", P.dados[P.topo]);
		P.topo--;
	}
	else {
		printf("Pilha vazia\n");
	}
	return P;
}

void mostra(Pilha P) {
	printf("Pilha atual\n");
	int i;
	for (i = 0; i <= P.topo; i++) {
		printf("%d\n", P.dados[i]);
	}
}

Pilha copiar(Pilha origem, Pilha destino) {
	Pilha aux = inicializar();
	int i;
	for (i = origem.topo; i >= 0; i--) {
		aux = empilhar(aux, origem.dados[i]);
	}
	for (i = aux.topo; i >= 0; i--) {
		destino = empilhar(destino, aux.dados[i]);
	}
	return destino;
}

int main() {
	Pilha P1 = inicializar();
	Pilha P2 = inicializar();
	int valor;
	int i;
	int qtd;
	printf("Quantos elementos deseja empilhar na pilha P1?");
	scanf_s("%d", &qtd);
	for (i = 0; i < qtd; i++) {
		printf("Digite o valor %d:", i + 1);
		scanf_s("%d", &valor);
		P1 = empilhar(P1, valor);
	}
	printf("Pilha P1 original:\n");
	mostra(P1);
	P2 = copiar(P1, P2);
	printf("Pilha P2 copiada:\n");
	mostra(P2);
	return 0;
}