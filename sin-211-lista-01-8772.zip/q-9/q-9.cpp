#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 50

typedef struct sPilha {
	char dados[MAX];
	int topo;
}Pilha;

Pilha inicializar() {
	Pilha P;
	P.topo = -1;
	return P;
}

int cheia(Pilha P) {
	return P.topo == MAX - 1;
}

int vazia(Pilha P) {
	return P.topo == -1;
}

Pilha empilhar(Pilha P, char valor) {
	if (!cheia(P)) {
		P.topo++;
		P.dados[P.topo] = valor;
	}
	else {
		printf("Pilha cheia \n");
	}
	return P;
}

Pilha desempilhar(Pilha P) {
	if (!vazia(P)) {
		printf("DESEMPILHADA:%C \n", P.dados[P.topo]);
		P.topo--;
	}
	else {
		printf("Pilha vazia\n");
	}
	return P;
}

int sequenciavalida(char seq[]) {
	Pilha P = inicializar();
	int i = 0;
	while (seq[i] != '\0') {
		if (seq[i] == 'I') {
			P = empilhar(P, 'X');
		}
		else if (seq[i] == 'E') {
			if (vazia(P)) {
				return 0;
			}
			P = desempilhar(P);
		}
		i++;
	}
	if (vazia(P)) {
		return 1;
	}
	else {
		return 0;
	}
}

int main() {
	char seq[MAX];
	printf("Digite a sequencia de operacoes:\n");
	fgets(seq, MAX, stdin);
	if (sequenciavalida(seq)) {
		printf("VALIDA\n");
	}
	else {
		printf("INVALIDA\n");
	}
	return 0;
}