#include<stdio.h>
#include<stdlib.h>

#define MAX 100

typedef struct sPilha {
	int dados[MAX], topo;
}Pilha;

Pilha inicializar() {
	Pilha P;
	P.topo = -1;
	return P;
}

int cheia(Pilha P) {
	return P.topo == MAX - 1;
}

int vazia(Pilha P) {
	return P.topo == -1;
}

Pilha empilhar(Pilha P, int valor) {
	if (!cheia(P)) {
		P.topo++;
		P.dados[P.topo]=valor;
	}
	else {
		printf("Pilha cheia\n");
	}
	return P;
}

Pilha desempilhar(Pilha P) {
	if (!vazia(P)) {
		printf("DESEMPILHADA:%d", P.dados[P.topo]);
		P.topo--;
	}
	else {
		printf("Pilha Vazia\n");
	}
	return P;
}

int maior(Pilha P) {
	int i;
	int maior = P.dados[0];
	for (i = 1; i <= P.topo; i++) {
		if (P.dados[i] > maior) {
			maior = P.dados[i];
		}
	}
	return maior;
}

int menor(Pilha P) {
	int i;
	int menor = P.dados[0];
	for (i = 1; i <= P.topo; i++) {
		if (P.dados[i] < menor) {
			menor = P.dados[i];
		}
	}
	return menor;
}

float media(Pilha P) {
	int i;
	int soma = 0;
	for (i = 0; i <= P.topo; i++) {
		soma += P.dados[i];
	}
	return (float)soma / (P.topo + 1);
}

int main() {
	Pilha P = inicializar();
	int quantidade, i, numeros;

	printf("Quantos valores vc deseja empilhar? \n");
	scanf_s("%d", &quantidade);
	for (i = 0; i < quantidade; i++) {
		printf("Digite os numeros %d \n", i + 1);
		scanf_s("%d", &numeros);
		P = empilhar(P, numeros);
	}
	if (!vazia(P)) {
		printf("Maior numero e:%d \n", maior(P));
		printf("Menor numero e:%d \n", menor(P));
		printf("A media dos numero e:%.2f \n",media(P));
	}
	return 0;

}
