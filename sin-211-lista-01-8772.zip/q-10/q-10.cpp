#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

typedef struct sPilha {
	int topo;
	char dados[100];
}Pilha;

Pilha inicializar() {
	Pilha P;
	P.topo = -1;
	return P;
}

int cheia(Pilha P) {
	return P.topo == MAX - 1;
}

int vazia(Pilha P) {
	return P.topo == -1;
}

Pilha empilhar(Pilha P, char dados) {
	if (!cheia(P)) {
		P.topo++;
		P.dados[P.topo] = dados; 
	}
	else {
		printf("Pilha cheia\n");
	}
	return P;
}

Pilha desempilhar(Pilha P) {
	if (!vazia(P)) {
		printf("%c", P.dados[P.topo]);
		P.topo--;
	}
	else {
		printf("Pilha vazia\n");
	}
	return P;
}

void inverte(char frase[]) {
	Pilha P = inicializar();
	int i=0;
	while (frase[i] != '\0') {
		P = empilhar(P, frase[i]);
		i++;
	}
	while (P.topo >= 0) {
		P = desempilhar(P);
	}
}

int main() {
	char texto[MAX];
	char frase[MAX];
	int i = 0;
	int j = 0;
	printf("Digite a frase\n");
	fgets(texto, MAX, stdin);
	while (texto[i] != '.') {
		if (texto[i] != ' ' && texto[i] != '\n') {
			frase[j] = texto[i];
			j++;
		}
		else {
			frase[j] = '\0';
			inverte(frase);
			printf(" ");
			j = 0;
		}
		i++;
	}
	frase[j] = '\0';
	inverte(frase);
	return 0;
}