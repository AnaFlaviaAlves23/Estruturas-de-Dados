#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

typedef struct {
    int codigo;
    char sobrenome[30];
    int anonasc;
} Funcionario;

void cadastrar(Funcionario funcionarios[], int* quantidade) {
    if (*quantidade >= MAX) {
        printf("Limite de funcionarios atingido.\n");
        return;
    }

    printf("Digite o codigo do funcionario: ");
    scanf_s("%d", &funcionarios[*quantidade].codigo);

    printf("Digite o sobrenome do funcionario: ");
    scanf_s("%s", funcionarios[*quantidade].sobrenome, (unsigned)_countof(funcionarios[*quantidade].sobrenome));

    printf("Digite o ano de nascimento do funcionario: ");
    scanf_s("%d", &funcionarios[*quantidade].anonasc);

    (*quantidade)++;
    printf("Funcionario cadastrado com sucesso!\n\n");
}

void listar(Funcionario funcionarios[], int quantidade) {
    if (quantidade == 0) {
        printf("Nenhum funcionario cadastrado.\n");
        return;
    }

    printf("Lista de Funcionarios:\n");
    for (int i = 0; i < quantidade; i++) {
        printf("Codigo: %d\n", funcionarios[i].codigo);
        printf("Sobrenome: %s\n", funcionarios[i].sobrenome);
        printf("Ano de nascimento: %d\n\n", funcionarios[i].anonasc);
    }
}

void buscar(Funcionario funcionarios[], int quantidade) {
    int codigo;
    int achou = 0;

    printf("Digite o codigo do funcionario para buscar: ");
    scanf_s("%d", &codigo);

    for (int i = 0; i < quantidade; i++) {
        if (funcionarios[i].codigo == codigo) {
            printf("Funcionario encontrado:\n");
            printf("Codigo: %d\n", funcionarios[i].codigo);
            printf("Sobrenome: %s\n", funcionarios[i].sobrenome);
            printf("Ano de nascimento: %d\n", funcionarios[i].anonasc);
            achou = 1;
            break;
        }
    }

    if (!achou) {
        printf("Funcionario nao encontrado.\n");
    }
}

void deletar(Funcionario funcionarios[], int* quantidade) {
    int codigo, i, j;
    printf("Digite o codigo do funcionario para deletar: ");
    scanf_s("%d", &codigo);

    for (i = 0; i < *quantidade; i++) {
        if (funcionarios[i].codigo == codigo) {
            for (j = i; j < *quantidade - 1; j++) {
                funcionarios[j] = funcionarios[j + 1];
            }
            (*quantidade)--;
            printf("Funcionario deletado com sucesso.\n");
            return;
        }
    }
    printf("Funcionario nao encontrado.\n");
}

int main() {
    Funcionario funcionarios[MAX];
    int quantidade = 0;
    int opcao;

    do {
        printf("\nMenu:\n");
        printf("1 - Cadastrar Funcionario\n");
        printf("2 - Listar Funcionarios\n");
        printf("3 - Buscar Funcionario\n");
        printf("4 - Deletar Funcionario\n");
        printf("5 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf_s("%d", &opcao);

        switch (opcao) {
        case 1:
            cadastrar(funcionarios, &quantidade);
            break;
        case 2:
            listar(funcionarios, quantidade);
            break;
        case 3:
            buscar(funcionarios, quantidade);
            break;
        case 4:
            deletar(funcionarios, &quantidade);
            break;
        case 5:
            printf("Encerrando programa...\n");
            break;
        default:
            printf("Opcao invalida.\n");
        }

    } while (opcao != 5);

    return 0;
}
