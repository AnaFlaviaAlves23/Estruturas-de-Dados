#include<stdio.h>
#include<stdlib.h>

#define MAX 50

typedef struct sPilha {
	int dados[MAX];
	int topo;
}Pilha;

Pilha inicializar() {
	Pilha P;
	P.topo = -1;
	return P;
}

int cheia(Pilha P) {
	return P.topo == MAX - 1;
}

int vazia(Pilha P) {
	return P.topo == -1;
}

Pilha empilhar(Pilha P, int valor) {
	if (!cheia(P)) {
		P.topo++;
		P.dados[P.topo]=valor;
	}
	else {
		printf("Pilha cheia\n");
	}
	return P;
}
/*
Pilha desempilhar(Pilha P){
	if(!vazia(P)){
		printf("DESEMPILHADA:%D",P.dados[P.topo]);
		P.topo--;
	}
	else{
		printf("Pilha vaiza\n");
	}
	return P;
*/

Pilha inverter(Pilha P) {
	Pilha aux = inicializar();
	int i;
	for (i = P.topo; i >= 0; i--) {
		aux = empilhar(aux, P.dados[i]);
	}
	return aux;
}
void mostrar(Pilha P) {
	int i;
	for (i = 0; i <= P.topo; i++) {
		printf("%d \n", P.dados[i]);
	}
}

int main() {
	Pilha P = inicializar();
	int quantidade;
	int i;
	int valor;
	printf("Quantos valores deseja empilhar?\n");
	scanf_s("%d", &quantidade);
	for (i = 0; i < quantidade; i++) {
		printf("Digite o valor %d:\n", i + 1);
		scanf_s("%d", &valor);
		P = empilhar(P, valor);
	}
	printf("Pilha original:\n");
	mostrar(P);
	P = inverter(P);
	printf("Pilha invertida:\n");
	mostrar(P);
	return 0;
}