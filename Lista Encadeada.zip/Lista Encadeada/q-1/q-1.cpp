#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Lista {
	Elemento* inicio;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int inserirfinal(int valor, Lista* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (lista->inicio == NULL) {
		lista->inicio = no;
	}
	else {
		Elemento* aux = lista->inicio;
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = no;
	}
	lista->tamanho++;
	return 1;
}

int contar(Lista* lista) {
	int contador = 0;
	Elemento* aux = lista->inicio;
	while (aux != NULL) {
		contador++;
		aux = aux->prox;
	}
	return contador;
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Vazia\n");
	}else {
		printf("\n");
		while ("%d", no->valor) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

int main() {
	Lista Lista1;
	criar(&Lista1);
	int valor;
	printf("Digite valores para inserir na sua lista(digite o 0 para parar)\n");
	while (1) {
		printf("Valor:\n");
		scanf_s("%d", &valor);
		if (valor == 0) {
			break;
		}
		inserirfinal(valor, &Lista1);
	}
	int total = contar(&Lista1);
	printf("Total de numeros na lista e:%d\n", total);
	return 0;
}

