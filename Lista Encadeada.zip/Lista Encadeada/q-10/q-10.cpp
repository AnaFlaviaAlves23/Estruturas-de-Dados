#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Lista {
	Elemento* inicio;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int inserirfinal(int valor, Lista* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (lista->inicio == NULL) {
		lista->inicio = no;
	}
	else {
		Elemento* aux = lista->inicio;
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = no;
	}
	lista->inicio++;
	return 0;
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Vazia");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

void destruir(Lista* lista) {
	Elemento* atual = lista->inicio, * no;
	if (lista->inicio != NULL) {
		while (atual != NULL) {
			no = atual;
			atual = atual->prox;
			free(no);
		}
		lista->inicio = NULL;
		lista->tamanho = 0;
	}
	else {
		printf("Vazia");
	}
}

int ordenar(Lista *lista) {
	if (lista->inicio == NULL||lista->inicio->prox==NULL) {
		return 1;
	}
	Elemento* atual = lista->inicio;
	while (atual->prox != NULL) {
		if (atual->valor > atual->prox->valor) {
			return 0;
		}
		atual = atual->prox;
	}
	return 1;
}

int main() {
	Lista lista;
	criar(&lista);

	int opcao, valor;

	do {
		printf("MENU\n");
		printf("1 - Inserir numero\n");
		printf("2 - Mostrar lista\n");
		printf("3 - Verificar se esta ordenada\n");
		printf("0 - Sair\n");
		printf("Escolha uma opcao:\n ");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Digite um numero\n: ");
			scanf_s("%d", &valor);
			if (inserirfinal(valor, &lista)) {
				printf("Numero inserido com sucesso\n");
			}
			else {
				printf("Erro ao inserir numero\n");
			}
			break;

		case 2:
			mostrar(&lista);
			break;

		case 3:
			if (ordenar(&lista)) {
				printf("A lista esta ordenada de forma crescente.\n");
			}
			else {
				printf("A lista nao esta ordenada.\n");
			}
			break;

		case 0:
			destruir(&lista);
			printf("Saindo...\n");
			break;

		default:
			printf("Opcao invalida.\n");
		}

	} while (opcao != 0);

	return 0;
}
