#include <stdio.h>
#include <stdlib.h>

typedef struct Elemento {
    int valor;
    struct Elemento* prox;
} Elemento;

typedef struct Lista {
    Elemento* inicio;
    int tamanho;
} Lista;


int inserirfinal(int valor, Lista* lista) {
    Elemento* no = (Elemento*)malloc(sizeof(Elemento));
    if (lista == NULL || no == NULL) {
        return 0;
    }
    no->valor = valor;
    no->prox = NULL;

    if (lista->inicio == NULL) {
        lista->inicio = no;
    }
    else {
        Elemento* aux = lista->inicio;
        while (aux->prox != NULL) {
            aux = aux->prox;
        }
        aux->prox = no;
    }
    lista->tamanho++;
    return 1;
}

void mostrar(Lista* lista) {
    Elemento* no = lista->inicio;
    if (no == NULL) {
        printf("Lista vazia\n");
        return;
    }

    printf("Lista: ");
    while (no != NULL) {
        printf("%d ", no->valor);
        no = no->prox;
    }
    printf("\n");
}


void ordenar(Lista* lista) {
    Elemento* i, * j;
    int temp;

    if (lista == NULL || lista->inicio == NULL) {
        return;
    }

    for (i = lista->inicio; i->prox != NULL; i = i->prox) {
        for (j = i->prox; j != NULL; j = j->prox) {
            if (i->valor > j->valor) {
                temp = i->valor;
                i->valor = j->valor;
                j->valor = temp;
            }
        }
    }
    printf("Lista ordenada com sucesso!\n");
}

int main() {
    Lista lista;
    lista.inicio = NULL;
    lista.tamanho = 0;

    int opcao, numero;

    do {
        printf("MENU\n");
        printf("1 - Inserir numero\n");
        printf("2 - Ordenar lista\n");
        printf("3 - Exibir lista\n");
        printf("0 - Sair\n");
        printf("Opcao: ");
        scanf_s("%d", &opcao);

        switch (opcao) {
        case 1:
            printf("Digite um numero: \n");
            scanf_s("%d", &numero);
            inserirfinal(numero, &lista);
            break;

        case 2:
            ordenar(&lista);
            break;

        case 3:
            mostrar(&lista);
            break;

        case 0:
            printf("Saindo\n");
            break;

        default:
            printf("Opcao invalida!\n");
        }
    } while (opcao != 0);

    return 0;
}
