#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Lista {
	Elemento* inicio;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->tamanho = NULL;
	lista->tamanho = 0;
}

int inserirfinal(int valor, Lista* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (lista->inicio == NULL) {
		lista->inicio = no;
	}
	else {
		Elemento* aux = lista->inicio;
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = no;
	}
	lista->tamanho++;
	return 1;
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Lista Vazia");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}


void destruir(Lista* lista) {
	Elemento* atual = lista->inicio, * no;
	if (lista->inicio != NULL) {
		while (atual != NULL) {
			no = atual;
			atual = atual->prox;
			free(no);
		}
		lista->inicio = NULL;
		lista->tamanho = 0;
	}
	else {
		printf("Vazia");
	}
}

Lista pares(Lista* original) {
	Lista nova;
	criar(&nova);
	Elemento* atual = original->inicio;
	while (atual != NULL) {
		if (atual->valor % 2 == 0) {
			inserirfinal(atual->valor, &nova);
		}
		atual = atual->prox;
	}
	return nova;
}

int main() {
	Lista lista;
	criar(&lista);

	int opcao, valor;
	Lista pares;

	do {
		printf("MENU\n");
		printf("1 - Inserir numero\n");
		printf("2 - Mostrar lista\n");
		printf("3 - Criar lista com pares\n");
		printf("4 - Sair\n");
		printf("Escolha uma opcao:\n ");
		scanf("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Digite o valor positivo:\n ");
			scanf("%d", &valor);
			if (valor > 0) {
				inserirfinal(valor, &lista);
			}
			else {
				printf("Apenas valores positivos sao permitidos\n");
			}
			break;

		case 2:
			mostrar(&lista);
			break;

		case 3:
			pares = pares(&lista);
			printf("Lista com numeros pares:\n");
			mostrar(&pares);
			destruir(&pares); 
			break;

		case 4:
			destruir(&lista);
			printf("Saindo...\n");
			break;

		default:
			printf("Opcao invalida.\n");
		}
	} while (opcao != 0);

	return 0;
}