#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Lista {
	Elemento* inicio;
	Elemento* fim;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int vazia(Lista* lista) {
	if (lista->inicio == NULL) {
		return 1;
	}
	return 0;
}

int contar(Lista* lista) {
	int contador = 0;
	Elemento* aux = lista->inicio;
	while (aux != NULL) {
		contador++;
		aux = aux->prox;
	}
	return contador;
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Vazia");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

int inserir(int valor, Lista* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (no == NULL) return 0;
	no->valor = valor;

	if (vazia(lista)) {
		no->prox = no;
		lista->inicio = no;
		lista->fim = no;
	}
	else {
		Elemento* atual = lista->inicio;
		Elemento* anterior = lista->fim;
		do {
			if (atual->valor >= valor) break;
			anterior = atual;
			atual = atual->prox;
		} while (atual != lista->inicio);

		no->prox = atual;
		anterior->prox = no;

		if (atual == lista->inicio && valor < atual->valor) {
			lista->inicio = no;
		}
		if (anterior == lista->fim && valor >= lista->fim->valor) {
			lista->fim = no;
		}
	}
	lista->tamanho++;
	return 1;
}

Lista copiar(Lista* lista) {
	Lista copia;
	criar(&copia);
	criar(&copia);
	if (vazia(lista)) {
		return copia;
	}
	Elemento* atual = lista->fim->prox;
	do {
		inserir(atual->valor,&copia);
		atual = atual->prox;
	} while (atual != lista->fim->prox);
	return copia;
}

void concatenar(Lista* L1, Lista* L2) {
	if (L2->inicio == NULL) {
		return;
	}
	if (L1->inicio == NULL) {
		L1->inicio = L2->inicio;
	}
	else {
		Elemento* aux = L1->inicio;
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = L2->inicio;
	}
	L1->tamanho += L2->tamanho;
	L2->inicio = NULL;
	L2->tamanho = 0;
}

Lista intercalar(Lista* L1, Lista* L2) {
	Lista L3;
	criar(&L3);
	Elemento* A = L1->inicio;
	Elemento* B = L2->inicio;
	int LA = contar(L1);
	int LB = contar(L2);
	while (LA > 0 && LB > 0) {
		if (A->valor <= B->valor) {
			inserir(A->valor, &L3);
			A = A->prox;
			LA--;
		}
		else {
			inserir(B->valor, &L3);
			B= B->prox;
			LB--;
		}
	}
	while (LA --> 0) {
		inserir(A->valor, &L3);
		A = A->prox;
	}
	while (LB -->0) {
		inserir(B->valor, &L3);
		B = B->prox;
	}
	return L3;
}

void destruir(Lista* lista) {
	Elemento* atual = lista->inicio;
	while (atual != NULL) {
		Elemento* temp = atual;
		atual = atual->prox;
		free(temp);
	}
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int main() {
	Lista lista1, lista2, lista3;
	int opcao, valor;
	criar(&lista1);
	criar(&lista2);

	do {
		printf("MENU LISTA CIRCULAR\n");
		printf("1- Inserir na Lista 1\n");
		printf("2- Inserir na Lista 2\n");
		printf("3- Mostrar Lista 1\n");
		printf("4- Mostrar Lista 2\n");
		printf("5- Contar elementos Lista 1\n");
		printf("6- Concatenar Lista 2 na Lista 1\n");
		printf("7- Intercalar Listas 1 e 2\n");
		printf("8- Copiar Lista 1\n");
		printf("9- Sair\n");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Digite valor: ");
			scanf_s("%d", &valor);
			inserir(valor, &lista1);
			break;
		case 2:
			printf("Digite valor: ");
			scanf_s("%d", &valor);
			inserir(valor, &lista2);
			break;
		case 3:
			mostrar(&lista1);
			break;
		case 4:
			mostrar(&lista2);
			break;
		case 5:
			printf("Lista 1 tem %d elementos\n", contar(&lista1));
			break;
		case 6:
			concatenar(&lista1, &lista2);
			break;
		case 7:
			lista3 = intercalar(&lista1, &lista2);
			mostrar(&lista3);
			destruir(&lista3);
			break;
		case 8:
			lista3 = copiar(&lista1);
			mostrar(&lista3);
			destruir(&lista3);
			break;
		case 9:
			printf("Saindo\n");
			break;
		default:
			printf("Opcao invalida!\n");
		}
	} while (opcao != 0);

	destruir(&lista1);
	destruir(&lista2);
	return 0;
}






