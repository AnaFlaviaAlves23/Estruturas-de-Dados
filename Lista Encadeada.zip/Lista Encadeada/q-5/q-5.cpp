#include <stdio.h>
#include <stdlib.h>

typedef struct Elemento {
    int valor;
    struct Elemento* prox;
} Elemento;

typedef struct Lista {
    Elemento* inicio;
    int tamanho;
} Lista;

void criar(Lista* lista) {
    lista->inicio = NULL;
    lista->tamanho = 0;
}

int inserirInicio(Lista* lista, int valor) {
    Elemento* no = (Elemento*)malloc(sizeof(Elemento));
    if (no == NULL) return 0;

    no->valor = valor;
    no->prox = lista->inicio;
    lista->inicio = no;
    lista->tamanho++;
    return 1;
}

int remover(Lista* lista, int valor) {
    Elemento* ant = NULL;
    Elemento* no = lista->inicio;

    if (no == NULL) return 0;

    while (no != NULL && no->valor != valor) {
        ant = no;
        no = no->prox;
    }

    if (no == NULL) return 0;

    if (ant == NULL) {
        lista->inicio = no->prox;
    }
    else {
        ant->prox = no->prox;
    }

    free(no);
    lista->tamanho--;
    return 1;
}

void mostrar(Lista* lista) {
    Elemento* no = lista->inicio;

    if (no == NULL) {
        printf("Lista vazia.\n");
        return;
    }

    printf("Lista: ");
    while (no != NULL) {
        printf("%d ", no->valor);
        no = no->prox;
    }
    printf("\n");
}

int buscar(Lista* lista, int valor) {
    Elemento* no = lista->inicio;
    int pos = 0;

    while (no != NULL) {
        if (no->valor == valor)
            return pos;
        no = no->prox;
        pos++;
    }

    return -1;
}

void inverter(Lista* lista) {
    Elemento* anterior = NULL;
    Elemento* atual = lista->inicio;
    Elemento* proximo = NULL;

    while (atual != NULL) {
        proximo = atual->prox;
        atual->prox = anterior;
        anterior = atual;
        atual = proximo;
    }

    lista->inicio = anterior;
}

int main() {
    Lista lista;
    criar(&lista);
    int opcao, valor, posicao;

    do {
        printf("\n--- MENU ---\n");
        printf("1 - Inserir Elemento\n");
        printf("2 - Remover Elemento\n");
        printf("3 - Listar Elementos\n");
        printf("4 - Buscar Elemento\n");
        printf("5 - Inverter Lista\n");
        printf("0 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf_s("%d", &opcao);

        switch (opcao) {
        case 1:
            printf("Digite o valor a inserir: ");
            scanf_s("%d", &valor);
            if (inserirInicio(&lista, valor))
                printf("Inserido com sucesso!\n");
            else
                printf("Erro ao inserir.\n");
            break;

        case 2:
            printf("Digite o valor a remover: ");
            scanf_s("%d", &valor);
            if (remover(&lista, valor))
                printf("Removido com sucesso.\n");
            else
                printf("Valor nao encontrado.\n");
            break;

        case 3:
            mostrar(&lista);
            break;

        case 4:
            printf("Digite o valor a buscar: ");
            scanf_s("%d", &valor);
            posicao = buscar(&lista, valor);
            if (posicao != -1)
                printf("Valor encontrado na posicao %d.\n", posicao);
            else
                printf("Valor nao encontrado.\n");
            break;

        case 5:
            inverter(&lista);
            printf("Lista invertida com sucesso!\n");
            break;

        case 0:
            printf("Encerrando o programa.\n");
            break;

        default:
            printf("Opcao invalida.\n");
        }

    } while (opcao != 0);

    return 0;
}
