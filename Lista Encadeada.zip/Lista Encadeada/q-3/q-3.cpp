#include <stdio.h>
#include <stdlib.h>

typedef struct Elemento {
    int valor;
    struct Elemento* prox;
} Elemento;

typedef struct Lista {
    Elemento* inicio;
    int tamanho;
} Lista;

void criar(Lista* lista) {
    lista->inicio = NULL;
    lista->tamanho = 0;
}

int inserir(int valor, Lista* lista) {
    Elemento* no = (Elemento*)malloc(sizeof(Elemento));
    if (no == NULL) return 0;

    no->valor = valor;
    no->prox = NULL;

    if (lista->inicio == NULL) {
        lista->inicio = no;
    }
    else {
        Elemento* aux = lista->inicio;
        while (aux->prox != NULL) {
            aux = aux->prox;
        }
        aux->prox = no;
    }

    lista->tamanho++;
    return 1;
}

void mostrar(Lista* lista) {
    Elemento* aux = lista->inicio;
    if (aux == NULL) {
        printf("(lista vazia)\n");
        return;
    }
    while (aux != NULL) {
        printf("%d ", aux->valor);
        aux = aux->prox;
    }
    printf("\n");
}

int contar(Lista* lista) {
    int cont = 0;
    Elemento* aux = lista->inicio;
    while (aux != NULL) {
        cont++;
        aux = aux->prox;
    }
    return cont;
}

void concatenar(Lista* lista1, Lista* lista2) {
    if (lista2->inicio == NULL) return;

    if (lista1->inicio == NULL) {
        lista1->inicio = lista2->inicio;
    }
    else {
        Elemento* aux = lista1->inicio;
        while (aux->prox != NULL) {
            aux = aux->prox;
        }
        aux->prox = lista2->inicio;
    }

    lista1->tamanho += lista2->tamanho;
    lista2->inicio = NULL;
    lista2->tamanho = 0;
}

int main() {
    Lista lista1, lista2;
    criar(&lista1);
    criar(&lista2);

    int valor;

    printf("Digite os valores da lista1 (digite 0 para parar):\n");
    while (1) {
        printf("Valor: ");
        scanf_s("%d", &valor);
        if (valor == 0) break;
        inserir(valor, &lista1);
    }

    printf("Digite os valores da lista2 (digite 0 para parar):\n");
    while (1) {
        printf("Valor: ");
        scanf_s("%d", &valor);
        if (valor == 0) break;
        inserir(valor, &lista2);
    }

    concatenar(&lista1, &lista2);

    printf("Lista final ap�s a concatena��o : \n");
    mostrar(&lista1);

    int total = contar(&lista1);
    printf("Total de c�lulas na lista: %d\n", total);

    return 0;
}
