#include <stdio.h>
#include <stdlib.h>



typedef struct Elemento {
    int valor;
    struct Elemento* prox;
} Elemento;

typedef struct Lista {
    Elemento* inicio;
    int tamanho;
} Lista;


void criar(Lista* lista) {
    lista->inicio = NULL;
    lista->tamanho = 0;
}

int inseririnicio(int valor, Lista* lista) {
    Elemento* no = (Elemento*)malloc(sizeof(Elemento));
    if (no == NULL) return 0;

    no->valor = valor;
    no->prox = lista->inicio;
    lista->inicio = no;
    lista->tamanho++;
    return 1;
}

int remover(int valor, Lista* lista) {
    if (lista->inicio == NULL) return 0;

    Elemento* no = lista->inicio;
    Elemento* ant = NULL;

    while (no != NULL && no->valor != valor) {
        ant = no;
        no = no->prox;
    }

    if (no == NULL) return 0;

    if (ant == NULL) {
        lista->inicio = no->prox;
    }
    else {
        ant->prox = no->prox;
    }

    free(no);
    lista->tamanho--;
    return 1;
}

void mostrar(Lista* lista) {
    Elemento* no = lista->inicio;
    if (no == NULL) {
        printf("Lista vazia\n");
        return;
    }
    printf("Lista: ");
    while (no != NULL) {
        printf("%d ", no->valor);
        no = no->prox;
    }
    printf("\n");
}

int buscar(int valor, Lista* lista) {
    Elemento* no = lista->inicio;
    int pos = 0;
    while (no != NULL) {
        if (no->valor == valor) return pos;
        no = no->prox;
        pos++;
    }
    return -1;
}

void inverter(Lista* lista) {
    Elemento* anterior = NULL;
    Elemento* atual = lista->inicio;
    Elemento* proximo = NULL;
    while (atual != NULL) {
        proximo = atual->prox;
        atual->prox = anterior;
        anterior = atual;
        atual = proximo;
    }
    lista->inicio = anterior;
}

Elemento* encontrarMeio(Lista* lista) {
    Elemento* lento = lista->inicio;
    Elemento* rapido = lista->inicio;

    while (rapido != NULL && rapido->prox != NULL) {
        rapido = rapido->prox->prox;
        lento = lento->prox;
    }

    return lento;
}


int main() {
    Lista lista;
    criar(&lista);
    int opcao, valor;

    do {
        printf("\nMENU:\n");
        printf("1 - Inserir no in�cio\n");
        printf("2 - Remover um valor\n");
        printf("3 - Mostrar lista\n");
        printf("4 - Buscar valor\n");
        printf("5 - Inverter lista\n");
        printf("6 - Mostrar valor do meio\n");
        printf("0 - Sair\n");
        printf("Escolha: ");
        scanf_s("%d", &opcao);

        switch (opcao) {
        case 1:
            printf("Valor a inserir: ");
            scanf_s("%d", &valor);
            inseririnicio(valor, &lista);
            break;
        case 2:
            printf("Valor a remover: ");
            scanf_s("%d", &valor);
            if (remover(valor, &lista))
                printf("Removido com sucesso\n");
            else
                printf("Valor n�o encontrado\n");
            break;
        case 3:
            mostrar(&lista);
            break;
        case 4:
            printf("Valor a buscar: ");
            scanf_s("%d", &valor);
            int pos;
            pos = buscar(valor, &lista);
            if (pos != -1)
                printf("Encontrado na posi��o %d\n", pos);
            else
                printf("Valor n�o encontrado\n");
            break;
        case 5:
            inverter(&lista);
            printf("Lista invertida\n");
            break;
        case 6:
        {
            Elemento* meio = encontrarMeio(&lista);
            if (meio != NULL)
                printf("Elemento do meio: %d\n", meio->valor);
            else
                printf("Lista vazia\n");
        }
        break;
        case 0:
            printf("Saindo...\n");
            break;
        default:
            printf("Op��o inv�lida\n");
        }
    } while (opcao != 0);

    return 0;
}
