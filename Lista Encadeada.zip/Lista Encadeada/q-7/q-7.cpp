#include <stdio.h>
#include <stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
} Elemento;

typedef struct Lista {
	Elemento* inicio;
	int tamanho;
} Lista;

int inserirfinal(int valor, Lista* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;

	if (lista->inicio == NULL) {
		lista->inicio = no;
	}
	else {
		Elemento* aux = lista->inicio;
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = no;
	}
	lista->tamanho++;
	return 1;
}


void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Lista vazia\n");
	}
	else {
		printf("Lista: ");
		while (no != NULL) {
			printf("%d ", no->valor); 
			no = no->prox;
		}
		printf("\n");
	}
}

int maior(Lista* lista) {
	if (lista->inicio == NULL) {
		return -1;
	}
	int maior = lista->inicio->valor;
	Elemento* atual = lista->inicio->prox;

	while (atual != NULL) {
		if (atual->valor > maior) {
			maior = atual->valor;
		}
		atual = atual->prox;
	}
	return maior;
}

int menor(Lista* lista) {
	if (lista->inicio == NULL) {
		return -1;
	}
	int menor = lista->inicio->valor;
	Elemento* atual = lista->inicio->prox;

	while (atual != NULL) {
		if (atual->valor < menor) {
			menor = atual->valor;
		}
		atual = atual->prox;
	}
	return menor;
}


float media(Lista* lista) {
	if (lista == NULL || lista->inicio == NULL) {
		return 0.0;
	}
	Elemento* atual = lista->inicio;
	int soma = 0, cont = 0;

	while (atual != NULL) {
		soma += atual->valor;
		cont++;
		atual = atual->prox;
	}
	return (float)soma / cont;
}

int main() {
	Lista lista;
	lista.inicio = NULL;
	lista.tamanho = 0;

	int opcao, numero;

	do {
		printf("MENU\n");
		printf("1 - Inserir numero\n");
		printf("2 - Mostrar lista\n");
		printf("3 - Mostrar maior\n");
		printf("4 - Mostrar menor\n");
		printf("5 - Mostrar media\n");
		printf("0 - Sair\n");
		printf("Opcao: ");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Digite um numero: ");
			scanf_s("%d", &numero);
			inserirfinal(numero, &lista);
			break;

		case 2:
			mostrar(&lista);
			break;

		case 3:
			if (lista.inicio == NULL)
				printf("Lista vazia!\n");
			else
				printf("Maior: %d\n", maior(&lista));
			break;

		case 4:
			if (lista.inicio == NULL)
				printf("Lista vazia!\n");
			else
				printf("Menor: %d\n", menor(&lista));
			break;

		case 5:
			if (lista.inicio == NULL)
				printf("Lista vazia!\n");
			else
				printf("Media: %.2f\n", media(&lista));
			break;

		case 0:
			printf("Saindo...\n");
			break;

		default:
			printf("Op��o invalida!\n");
		}
	} while (opcao != 0);

	return 0;
}
