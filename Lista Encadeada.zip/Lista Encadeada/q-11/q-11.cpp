#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Lista {
	Elemento* inicio;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

void destruir(Lista* lista) {
	Elemento* atual = lista->inicio;
	while (atual != NULL) {
		Elemento* temp = atual;
		atual = atual->prox;
		free(temp);
	}
	lista->inicio = NULL;
	lista->tamanho = 0;
}


int inserirfinal(int valor, Lista* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (lista->inicio == NULL) {
		lista->inicio = no;
	}
	else {
		Elemento* aux = lista->inicio;
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = no;
	}
	lista->inicio++;
	return 0;
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Vazia");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}


Lista intercalar(Lista* A, Lista* B) {
	Lista C;
	criar(&C);

	Elemento* LA = A->inicio;
	Elemento* LB = B->inicio;

	while (LA != NULL && LB != NULL) {
		if (LA->valor <= LB->valor) {
			inserirfinal(LA->valor, &C);
			LA = LA->prox;
		}
		else {
			inserirfinal(LB->valor, &C);
			LB = LB->prox;
		}
	}
	while (LA != NULL) {
		inserirfinal(LA->valor, &C);
		LA = LA->prox;
	}

	while (LB != NULL) {
		inserirfinal(LB->valor, &C);
		LB = LB->prox;
	}

	return C;
}

int main() {
	Lista listaA, listaB, listaC;
	criar(&listaA);
	criar(&listaB);
	int opcao, valor;

	do {
		printf("MENU\n");
		printf("1 - Inserir valor na lista A\n");
		printf("2 - Inserir valor na lista B\n");
		printf("3 - Mostrar lista A\n");
		printf("4 - Mostrar lista B\n");
		printf("5 - Intercalar listas A e B e mostrar lista C\n");
		printf("6 - Sair\n");
		printf("Escolha uma opcao: ");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Digite valor (ordem crescente): ");
			scanf_s("%d", &valor);
			inserirfinal(valor, &listaA);
			break;

		case 2:
			printf("Digite valor (ordem crescente): ");
			scanf_s("%d", &valor);
			inserirfinal(valor, &listaB);
			break;

		case 3:
			printf("Lista A: ");
			mostrar(&listaA);
			break;

		case 4:
			printf("Lista B: ");
			mostrar(&listaB);
			break;

		case 5:
			listaC = intercalar(&listaA, &listaB);
			printf("Lista C (intercalada e ordenada): ");
			mostrar(&listaC);
			destruir(&listaC);
			break;

		case 6:
			destruir(&listaA);
			destruir(&listaB);
			printf("Saindo...\n");
			break;

		default:
			printf("Opcao invalida.\n");
		}

	} while (opcao != 0);

	return 0;
}







