#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Lista {
	Elemento* inicio;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int inserirfinal(int valor, Lista* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (lista->inicio == NULL) {
		lista->inicio = no;
	}
	else {
		Elemento* aux = lista->inicio;
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = no;
	}
	lista->tamanho++;
	return 1;
}

int contar(Lista* lista) {
	int contador = 0;
	Elemento* aux = lista->inicio;
	while (aux != NULL) {
		contador++;
		aux = aux->prox;
	}
	return contador;
}

void remover(int a, Lista* lista) {
	if (lista == NULL || lista->inicio == NULL) {
		return;
	}
	Elemento* atual = lista->inicio;
	Elemento* anterior = NULL;
	while (atual != NULL) {
		if (atual->valor == a) {
			if (anterior == NULL) {
				lista->inicio = atual->prox;
				free(atual);
				atual = lista->inicio;
			}
			else {
				anterior->prox = atual->prox;
				free(atual);
				atual = anterior->prox;
			}
			lista->tamanho--;
		}
		else {
			anterior = atual;
			atual = atual->prox;
		}
	}
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Vazia");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

int main() {
	Lista Lista1;
	criar(&Lista1);

	int valor;
	printf("Digite valores para inserir na lista (digite 0 para parar):\n");
	while (1) {
		printf("Valor: ");
		scanf_s("%d", &valor);
		if (valor == 0) {
			break;
		}
		inserirfinal(valor,&Lista1);
	}

	int numremover;
	printf("Digite um numero para remover da lista: ");
	scanf_s("%d", &numremover);

	remover(numremover, &Lista1);

	printf("Lista apos remocao:\n");
	mostrar(&Lista1);

	int total = contar(&Lista1);
	printf("Total de numeros na lista: %d\n", total);

	return 0;
}