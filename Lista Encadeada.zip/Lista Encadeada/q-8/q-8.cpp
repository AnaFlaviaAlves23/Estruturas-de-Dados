#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Lista {
	Elemento* inicio;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int inserirfinal(int valor, Lista* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (lista->inicio == NULL) {
		lista->inicio = no;
	}
	else {
		Elemento* aux = lista->inicio;
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = no;
	}
	lista->inicio++;
	return 0;
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Vazia");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

int remover(Lista* lista, int n) {
	if (lista == NULL || lista->inicio == NULL || n <= 0 || n > lista->tamanho) {
		return 0;
	}
	for (int i = 0; i < n; i++) {
		Elemento* temp = lista->inicio;
		lista->inicio = lista->inicio->prox;
		free(temp);
		lista->tamanho--;
	}
	return 1;
}

void destruir(Lista* lista) {
	Elemento* atual = lista->inicio, * no;
	if (lista->inicio != NULL) {
		while (atual != NULL) {
			no = atual;
			atual = atual->prox;
			free(no);
		}
		lista->inicio = NULL;
		lista->tamanho = 0;
	}
	else {
		printf("Vazia");
	}
}

int main() {
	Lista lista;
	criar(&lista);

	int opcao, valor, n;

	do {
		printf("MENU\n");
		printf("1 - Inserir numero\n");
		printf("2 - Mostrar lista\n");
		printf("3 - Remover n primeiros elementos\n");
		printf("0 - Sair\n");
		printf("Escolha uma opcaoo: ");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Digite o valor: ");
			scanf_s("%d", &valor);
			if(inserirfinal(valor, &lista)) {
				printf("N�mero inserido com sucesso!\n");
			}
			else {
				printf("Erro ao inserir numero.\n");
			}
			break;

		case 2:
			mostrar(&lista);
			break;

		case 3:
			printf("Quantos elementos deseja remover do inicio? ");
			scanf_s("%d", &n);
			if (remover(&lista, n)) {
				printf("%d elementos removidos com sucesso.\n", n);
			}
			else {
				printf("N�o foi possivel remover os elementos.\n");
			}
			break;

		case 0:
			destruir(&lista);
			printf("Saindo...\n");
			break;

		default:
			printf("Op��o invalida.\n");
		}

	} while (opcao != 0);

	return 0;
}



