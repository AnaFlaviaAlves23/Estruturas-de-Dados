#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Fila {
	Elemento* inicio;
	Elemento* fim;
	int tamanho;
}Fila;

void criar(Fila* fila) {
	fila->inicio = fila->fim = NULL;
	fila->tamanho = 0;
}

int enfilerar(int valor, Fila* fila) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (fila == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (fila->fim == NULL) {
		fila->inicio = no;
	}
	else {
		fila->fim->prox = no;
	}
	fila->fim = no;
	fila->tamanho++;
	return 1;
}

int desenfilerar(Fila* fila) {
	if (fila->tamanho == 0 || fila->inicio == NULL) {
		return 0;
	}
	Elemento* no = fila->inicio;
	fila->inicio = no->prox;
	free(no);
	if (fila->inicio == NULL) {
		fila->inicio == NULL;
	}
	fila->tamanho--;
	return 1;
}

void exibir(Fila fila) {
	Elemento* atual = fila.inicio;
	while (atual != NULL) {
		printf("%d", atual->valor);
		atual = atual->prox;
	}
	printf("\n");
}

void remover(Fila* fila) {
	Fila temp;
	criar(&temp);
	while (fila->inicio != NULL) {
		int valor = fila->inicio->valor;
		desenfilerar(fila);
		if (valor >= 0) {
			enfilerar(valor, &temp);
		}
	}
	*fila = temp;
}

int main() {
	Fila fila;
	criar(&fila);
	int n;
	int valor;
	printf("Quantos valores deseja inserir na fila?\n");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf_s("%d", &valor);
		enfilerar(valor, &fila);
	}
	printf("Fila original\n");
	exibir(fila);
	remover(&fila);
	printf("Fila apos remover os valores negativos\n");
	exibir(fila);
	return 0;
	


}