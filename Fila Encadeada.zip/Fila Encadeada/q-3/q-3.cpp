#include <stdio.h>
#include <stdlib.h>

typedef struct Elemento {
    int valor;
    struct Elemento* prox;
} Elemento;

typedef struct Fila {
    Elemento* inicio;
    Elemento* fim;
    int tamanho;
} Fila;

void criar(Fila* fila) {
    fila->inicio = fila->fim = NULL;
    fila->tamanho = 0;
}

int enfilerar(int valor, Fila* fila) {
    if (fila == NULL) return 0;

    Elemento* no = (Elemento*)malloc(sizeof(Elemento));
    if (no == NULL) return 0;

    no->valor = valor;
    no->prox = NULL;

    if (fila->fim == NULL) {
        fila->inicio = no;
    }
    else {
        fila->fim->prox = no;
    }
    fila->fim = no;
    fila->tamanho++;
    return 1;
}

int desenfilerar(Fila* fila) {
    if (fila == NULL || fila->inicio == NULL) return 0;

    Elemento* no = fila->inicio;
    fila->inicio = no->prox;
    free(no);

    if (fila->inicio == NULL) {
        fila->fim = NULL;
    }
    fila->tamanho--;
    return 1;
}

int existir(Fila* fila, int valor) {
    Elemento* atual = fila->inicio;
    while (atual != NULL) {
        if (atual->valor == valor) {
            return 1;
        }
        atual = atual->prox;
    }
    return 0;
}

void unir(Fila* F1, Fila* F2) {
    Elemento* atual = F2->inicio;
    while (atual != NULL) {
        if (!existir(F1, atual->valor)) {
            enfilerar(atual->valor, F1);
        }
        atual = atual->prox;
    }
    while (F2->inicio != NULL) {
        desenfilerar(F2);
    }
}

void exibir(Fila fila) {
    Elemento* atual = fila.inicio;
    while (atual != NULL) {
        printf("%d ", atual->valor);
        atual = atual->prox;
    }
    printf("\n");
}

int main() {
    Fila F1, F2;
    criar(&F1);
    criar(&F2);
    int n, valor;

    printf("Quantos valores deseja inserir na Fila 1?\n");
    scanf_s("%d", &n);
    for (int i = 0; i < n; i++) {
        printf("Digite o valor %d na Fila 1:\n", i + 1);
        scanf_s("%d", &valor);
        enfilerar(valor, &F1);
    }

    printf("Quantos valores deseja inserir na Fila 2?\n");
    scanf_s("%d", &n);
    for (int i = 0; i < n; i++) {
        printf("Digite o valor %d na Fila 2:\n", i + 1);
        scanf_s("%d", &valor);
        enfilerar(valor, &F2);
    }

    printf("\nFila 1 antes de unir:\n");
    exibir(F1);

    printf("Fila 2 antes de unir:\n");
    exibir(F2);

    unir(&F1, &F2);

    printf("Fila 1 depois de unir (sem repeti��o):\n");
    exibir(F1);

    printf("Fila 2 depois de unir (deve estar vazia):\n");
    exibir(F2);

    return 0;
}
