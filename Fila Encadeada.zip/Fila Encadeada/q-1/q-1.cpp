#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Fila {
	Elemento* inicio;
	Elemento* fim;
	int tamanho;
}Fila;

void criar(Fila* fila) {
	fila->inicio=fila->fim= NULL;
	fila->tamanho = 0;
}

int enfilerar(int valor, Fila* fila) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (fila == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (fila->fim == NULL) {
		fila->inicio = no;
	}
	else {
		fila->fim->prox = no;
	}
	fila->fim = no;
	fila->tamanho++;
	return 1;
}

int desenfilerar(Fila* fila) {
	if (fila->tamanho == 0 || fila->inicio == NULL) {
		return 0;
	}
	Elemento* no = fila->inicio;
	fila->inicio = no->prox;
	free(no);
	if (fila->inicio == NULL) {
		fila->fim = NULL;
	}
	fila->tamanho--;
	return 1;
}

void removernegativos(Fila* fila) {
	Fila aux;
	criar(&aux);
	while (fila->inicio != NULL) {
		int valor = fila->inicio->valor;
		desenfilerar(fila);
		if (valor >= 0) {
			enfilerar(valor, &aux);
		}
	}
	while (aux.inicio != NULL) {
		int valor = aux.inicio->valor;
		desenfilerar(&aux);
		enfilerar(valor, fila);
	}
}

void exibir(Fila fila) {
	Elemento* atual = fila.inicio;
	while (atual != NULL) {
		printf("%d", atual->valor);
		atual = atual->prox;
	}
	printf("\n");
}

int main() {
	Fila fila;
	criar(&fila);
	int valor;
	printf("Digite os valores da fila(digite 000 para parar)\n");
	while (1) {
		scanf_s("%d", &valor);
		if (valor == 999) {
			break;
		}
		enfilerar(valor, &fila);
	}
	printf("Fila original\n");
	exibir(fila);
	removernegativos(&fila);
	printf("Fila sem negativos\n");
	exibir(fila);
	return 0;
}

