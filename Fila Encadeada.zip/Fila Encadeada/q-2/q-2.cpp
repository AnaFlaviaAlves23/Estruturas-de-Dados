#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Fila {
	Elemento* inicio;
	Elemento* fim;
	int tamanho;
}Fila;

void criar(Fila* fila) {
	fila->inicio = fila->fim = NULL;
	fila->tamanho = 0;
}

int enfilerar(int valor, Fila* fila) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (fila == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (fila->fim == NULL) {
		fila->inicio = no;
	}
	else {
		fila->fim->prox = no;
	}
	fila->fim = no;
	fila->tamanho++;
	return 1;
}

int desenfilerar(Fila* fila) {
	if (fila->tamanho == 0 || fila->inicio == NULL) {
		return 0;
	}
	Elemento* no = fila->inicio;
	fila->inicio = no -> prox;
	free(no);
	if (fila->inicio == NULL) {
		fila->fim == NULL;
	}
	fila->tamanho--;
	return 1;
}

void exibir(Fila fila) {
	Elemento* atual = fila.inicio;
	while (atual != NULL) {
		printf("%d", atual->valor);
		atual = atual->prox;
	}
	printf("\n");
}

void concatenar(Fila* F1, Fila* F2) {
	if (F2->inicio == NULL) {
		return;
	}
	if (F1->inicio == NULL) {
		F1->inicio = F2->inicio;
		F1->fim = F2->fim;
	}
	else {
		F1->fim->prox = F2->inicio;
		F1->fim = F2->fim;
	}
	F1->tamanho += F2->tamanho;
	F2->inicio = NULL;
	F2->fim =NULL;
	F2->tamanho = 0;
}

int main() {
	Fila F1, F2;
	criar(&F1);
	criar(&F2);
	int n, i, valor;
	printf("Quantos elementos deseja inserir na Fila 1?\n");
	scanf_s("%d", &n);
	for (i = 0; i < n; i++) {
		printf("Digite o valor %d da Fila1\n", i + 1);
		scanf_s("%d", &valor);
		enfilerar(valor, &F1);
	}
	printf("Quantos elementos deseja inserir na fila 2?\n");
	scanf_s("%d", &n);
	for (i = 0; i < n; i++) {
		printf("Digite o valor %d da Fila2\n", i + 1);
		scanf_s("%d", &valor);
		enfilerar(valor, &F2);
	}
	printf("Fila 1 antes da concatencao:\n");
	exibir(F1);
	printf("Fila 2 antes da concatencao:\n");
	exibir(F2);

	concatenar(&F1, &F2);
	printf("Fila 1 depois da concatencao:\n");
	exibir(F1);
	printf("Fila 2 depois da concatencao:\n");
	exibir(F2);
	return 0;

}

