#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Fila {
	Elemento* inicio;
	Elemento* fim;
	int tamanho;
}Fila;

void criar(Fila* fila) {
	fila->inicio = fila->fim = NULL;
	fila->tamanho = 0;
}

int enfilerar(char valor, Fila* fila) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (fila == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (fila->fim == NULL) {
		fila->inicio = no;
	}
	else {
		fila->fim->prox = no;
	}
	fila->fim = no;
	fila->tamanho++;
	return 1;
}

int desenfilerar(Fila* fila) {
	if (fila->tamanho == 0 || fila->inicio == NULL) {
		return 0;
	}
	Elemento* no = fila->inicio;
	fila->inicio = no->prox;
	free(no);
	if (fila->inicio == NULL) {
		fila->fim == NULL;
	}fila->tamanho--;
	return 1;
}

int acessar(int* valor, Fila* fila) {
	if (fila->inicio == NULL) {
		printf("Vazia\n");
		return 0;
	}
	*valor = fila->inicio->valor;
	return 1;
}

void exibir(Fila fila) {
	Elemento* atual = fila.inicio;
	while (atual != NULL) {
		printf("%d", atual->valor);
		atual = atual->prox;
	}
	printf("\n");
}

void unir(Fila* F1, Fila* F2, Fila* Resultado) {
	Elemento* a = F1->inicio;
	Elemento* b = F2->inicio;

	while (a != NULL && b != NULL) {
		if (a->valor <= b->valor) {
			enfilerar(a->valor, Resultado);
			a = a->prox;
		}
		else {
			enfilerar(b->valor, Resultado);
			b = b->prox;
		}
	}
	while (a != NULL) {
		enfilerar(a->valor, Resultado);
		a = a->prox;
	}
	while (b != NULL) {
		enfilerar(b->valor, Resultado);
		b = b->prox;
	}
}


int main() {
	Fila F1, F2, F3;
	criar(&F1);
	criar(&F2);
	criar(&F3);
	int n, valor;
	printf("Quantos valores deseja inserir na Fila 1(em ordem e crescente)?\n");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Digite o valor %d da Fila 1:\n", i + 1);
		scanf_s("%d", &valor);
		enfilerar(valor, &F1);
	}

	printf("Quantos valores deseja inserir na Fila 2(em ordem e crescente)?\n");
	scanf_s("%d", &n);
	for (int i = 0; i < n; i++) {
		printf("Digite o valor %d da Fila 2:\n", i + 1);
		scanf_s("%d", &valor);
		enfilerar(valor, &F2);
	}

	unir(&F1, &F2, &F3);
	printf("Fila1\n");
	exibir(F1);
	printf("Fila2\n");
	exibir(F2);
	printf("Fila3(unida em ordem e crescente\n");
	exibir(F3);
	return 0;
	
}


