#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Pilha {
	Elemento* topo;
	int tamanho;
}Pilha;

void criar(Pilha* PI) {
	PI->topo = NULL;
	PI->tamanho = 0;
}

int empilhar(int valor, Pilha* PI) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (PI==NULL) {
		return 0;
	}
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = PI->topo;
	PI->topo = no;
	PI->tamanho++;
	return 1;
}

int desempilhar(Pilha* PI,int* valor) {
	Elemento* no;
	if (PI->tamanho == 0 || PI->topo == NULL) {
		printf("Vazia");
		return 0;
	}
	no = PI->topo;
	*valor = no->valor;
	PI->topo = no->prox;
	free(no);
	PI->tamanho--;
	return 1;
}

void exibir(Pilha PI) {
	Elemento* atual = PI.topo;
	while (atual != NULL) {
		printf("%d ", atual->valor);
		atual = atual->prox;
	}
	printf("\n");
}

void inserirordem(Pilha* PI, int novo) {
	Pilha aux;
	criar(&aux);
	int valor;
	while (PI->topo != NULL && PI->topo->valor < novo) {
		desempilhar(PI,&valor);
		empilhar(valor,&aux);
	}
	empilhar(novo, PI);
	while (aux.topo != NULL) {
		desempilhar(&aux,&valor);
		empilhar(valor, PI);
	}
}

int main() {
	Pilha PI;
	criar(&PI);
	int n, valor, novo;

	printf("Quantos valores deseja inserir na pilha?\n");
	scanf_s("%d", &n);

	for (int i = 0; i < n; i++) {
		printf("Digite o valor %d: ", i + 1);
		scanf_s("%d", &valor);
		inserirordem(&PI, valor);
	}

	printf("Pilha atual\n");
	exibir(PI);

	printf("Digite um novo valor para inserir em ordem: \n");
	scanf_s("%d", &novo);
	inserirordem(&PI, novo);

	printf("Pilha apos a insercao ordenada:\n");
	exibir(PI);
}
