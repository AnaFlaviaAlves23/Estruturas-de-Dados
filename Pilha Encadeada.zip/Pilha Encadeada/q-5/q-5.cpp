#include<stdio.h>
#include<stdlib.h>


typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Pilha {
	Elemento* topo;
	int tamanho;
}Pilha;

void criar(Pilha* PI) {
	PI->topo == NULL;
	PI->tamanho = 0;
}

int empilhar(int valor, Pilha* PI) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (PI == NULL) {
		return 0;
	}
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = PI->topo;
	PI->topo = no;
	PI->tamanho++;
	return 1;
}

int desempilhar(Pilha* PI,int*valor) {
	Elemento* no;
	if (PI->tamanho == 0 || PI->topo == NULL) {
		printf("Vazia");
		return 0;
	}
	no = PI->topo;
	PI->topo = no->prox;
	free(no);
	PI->tamanho--;
	return 1;
}

void exibir(Pilha PI) {
	Elemento* atual = PI.topo;
	while (atual != NULL) {
		printf("%d", atual->valor);
		atual = atual->prox;
	}
	printf("\n");
}

void copiar(Pilha* P1, Pilha* P2) {
	Pilha aux;
	criar(&aux);
	int valor;
	while (P1->topo != NULL) {
		desempilhar(P1, &valor);
		empilhar(valor, &aux);
		
	}
	while (aux.topo != NULL) {
		desempilhar(&aux, &valor);
		empilhar(valor, P1);
		empilhar(valor, P2);
	}
}

int main() {
	Pilha P1, P2;
	criar(&P1);
	criar(&P2);
	int n, valor;

	printf("Quantos valores deseja empilhar na Pilha 1?");
	scanf_s("%d", &n);

	for (int i = 0; i < n; i++) {
		printf("Digite o valor %d: ", i + 1);
		scanf_s("%d", &valor);
		empilhar(valor, &P1);
	}
	
	printf("Pilha P1 original:\n");
	exibir(P1);

	copiar(&P1, &P2);

	printf("Copia da P1:\n");
	exibir(P2);

	return 0;
}