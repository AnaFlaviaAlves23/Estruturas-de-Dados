#include <stdio.h>
#include <stdlib.h>

typedef struct elemento {
    int valor;
    struct elemento* prox;
} Elem;

typedef struct EDFila {
    Elem* inicio;
    Elem* fim;
    int tamanho;
} Fila;

void criar(Fila* fila) {
    fila->inicio = fila->fim = NULL;
    fila->tamanho = 0;
}

int vazia(Fila* fila) {
    return fila->inicio == NULL;
}

int enfileirar(int valor, Fila* fila) {
    Elem* no = (Elem*)malloc(sizeof(Elem));
    if (no == NULL) return 0;

    no->valor = valor;
    no->prox = NULL;

    if (fila->fim == NULL) {
        fila->inicio = no;
    }
    else {
        fila->fim->prox = no;
    }

    fila->fim = no;
    fila->tamanho++;
    return 1;
}

int desenfileirar(Fila* fila, int* valor) {
    if (vazia(fila)) return 0;

    Elem* no = fila->inicio;
    if (valor != NULL)
        *valor = no->valor;

    fila->inicio = no->prox;
    free(no);
    if (fila->inicio == NULL)
        fila->fim = NULL;

    fila->tamanho--;
    return 1;
}

int acessar(int* valor, Fila* fila) {
    if (vazia(fila)) return 0;
    *valor = fila->inicio->valor;
    return 1;
}

void destruir(Fila* fila) {
    int temp;
    while (desenfileirar(fila, &temp));
}

typedef struct Pilha {
    Fila fila1;
    Fila fila2;
} Pilha;

void criarPilha(Pilha* p) {
    criar(&p->fila1);
    criar(&p->fila2);
}

void destruirPilha(Pilha* p) {
    destruir(&p->fila1);
    destruir(&p->fila2);
}

void empilhar(Pilha* p, int valor) {
    enfileirar(valor, &p->fila2);

    int temp;
    while (!vazia(&p->fila1)) {
        desenfileirar(&p->fila1, &temp);
        enfileirar(temp, &p->fila2);
    }

    Fila aux = p->fila1;
    p->fila1 = p->fila2;
    p->fila2 = aux;
}

int desempilhar(Pilha* p, int* valor) {
    return desenfileirar(&p->fila1, valor);
}

int topo(Pilha* p, int* valor) {
    return acessar(valor, &p->fila1);
}

int main() {
    Pilha pilha;
    int opcao, numero, resultado;

    do {
        printf("\n========= Pilha com Duas Filas =========");
        printf("\n1 Criar pilha.");
        printf("\n2 Destruir pilha.");
        printf("\n3 Push (empilhar).");
        printf("\n4 Pop (desempilhar).");
        printf("\n5 Topo da pilha.");
        printf("\n0 Sair.\n");
        scanf_s("%d", &opcao);

        switch (opcao) {
        case 1:
            criarPilha(&pilha);
            printf("\nPilha criada.");
            break;

        case 2:
            destruirPilha(&pilha);
            printf("Pilha destru�da.\n");
            break;

        case 3:
            printf("\nInforme um numero inteiro: ");
            scanf_s("%d", &numero);
            empilhar(&pilha, numero);
            break;

        case 4:
            resultado = desempilhar(&pilha, &numero);
            if (resultado)
                printf("Elemento desempilhado: %d\n", numero);
            else
                printf("Pilha vazia!\n");
            break;

        case 5:
            resultado = topo(&pilha, &numero);
            if (resultado)
                printf("Topo da pilha: %d\n", numero);
            else
                printf("Pilha vazia!\n");
            break;

        default:
            printf("Saindo.\n");
        }
    } while (opcao > 0 && opcao < 6);

    return 0;
}