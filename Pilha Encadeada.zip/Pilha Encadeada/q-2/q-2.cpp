#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Pilha {
	Elemento* topo;
	int tamanho;
}Pilha;

void criar(Pilha* PI) {
	PI->topo = NULL;
	PI->tamanho = 0;
}

int empilhar(int valor, Pilha* PI) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (PI == NULL) {
		return 0;
	}
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = PI->topo;
	PI->topo = no;
	PI->tamanho++;
	return 1;
}

int desempilhar(Pilha* PI) {
	Elemento* no;
	if (PI->tamanho == 0 || PI->topo == NULL) {
		printf("Vazia");
		return 0;
	}
	no = PI->topo;
	PI ->topo = no->prox;
	free(no);
	PI->tamanho--;
	return 1;
}

void exibir(Pilha PI) {
	Elemento* atual = PI.topo;
	while (atual != NULL) {
		printf("%d\n", atual->valor);
		atual = atual->prox;
	}
	printf("\n");
}

void separar(int valores[], int n, Pilha* Positiva, Pilha* Negativa) {
	for (int i = 0; i < n; i++) {
		if (valores[i] >= 0) {
			empilhar(valores[i], Positiva);
		}
		else {
			empilhar(valores[i], Negativa);
		}
	}
}

int main() {
	Pilha Positiva, Negativa;
	criar(&Positiva);
	criar(&Negativa);

	int n;
	printf("Quantos valores deseja?\n");
	scanf_s("%d", &n);

	
	int* valores = (int*)malloc(n * sizeof(int));
	if (valores == NULL) {
		printf("Erro ao alocar mem�ria!\n");
		return 1;
	}

	printf("Digite os valores:\n");
	for (int i = 0; i < n; i++) {
		scanf_s("%d", &valores[i]);
	}

	separar(valores, n, &Positiva, &Negativa);

	printf("Pilha Positiva:\n");
	exibir(Positiva);

	printf("Pilha Negativa:\n");
	exibir(Negativa);

	free(valores);
	return 0;
}