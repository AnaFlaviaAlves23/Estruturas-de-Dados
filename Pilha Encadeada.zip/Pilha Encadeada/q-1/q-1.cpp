#include<stdio.h>
#include<stdlib.h>

typedef struct Elemento {
	int valor;
	struct Elemento* prox;
}Elemento;

typedef struct Pilha {
	Elemento* topo;
	int tamanho;
}Pilha;

void criar(Pilha* PI) {
	PI->topo = NULL;
	PI->tamanho = 0;
}

int empilhar(int valor, Pilha* PI) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (PI == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;  
	no->prox = PI->topo;
	PI->topo = no;
	PI->tamanho++;
	return 1;
}

int desempilhar(Pilha* PI, int* valor) {
	Elemento* no;
	if (PI->tamanho == 0 || PI->topo == NULL) {
		printf("Pilha vazia\n");
		return 0;
	}
	no = PI->topo;
	*valor = no->valor;
	PI->topo = no->prox;
	free(no);
	PI->tamanho--;
	return 1;
}

void mostrar(Pilha PI) {
	Elemento* atual = PI.topo;
	while (atual != NULL) {
		printf("%d ", atual->valor);  
		atual = atual->prox;
	}
	printf("\n");
}

void inverte(Pilha* PI) {
	Pilha aux;
	criar(&aux);
	int valor;
	while (desempilhar(PI, &valor)) {
		empilhar(valor, &aux);
	}
	*PI = aux;
}

int main() {
	Pilha PI;
	criar(&PI);
	int n, valor;

	printf("Quantos valores deseja empilhar?\n");
	scanf_s("%d", &n);  

	for (int i = 0; i < n; i++) {
		printf("Digite o valor %d:\n", i + 1);
		scanf_s("%d", &valor);  
		empilhar(valor, &PI);
	}

	printf("Pilha invertida:\n");
	mostrar(PI);
	inverte(&PI);

	printf("Pilha original:\n");
	mostrar(PI);

	return 0;
}
