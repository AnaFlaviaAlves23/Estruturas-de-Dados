#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Elemento {
	int valor;
	struct Elemento* ant, * prox;
}Elemento;

typedef struct EDLista {
	Elemento* inicio;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int inserirfim(int valor, Lista* lista) {
	Elemento* aux = lista->inicio, * no = (Elemento*)malloc(sizeof(Elemento));
	if (no == NULL || lista == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (lista->inicio == NULL) {
		no->ant = NULL;
		lista->inicio = no;
	}
	else {
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = no;
		no->ant = aux;
	}
	lista->tamanho++;
	return 1;
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Lista Vazia\n");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

void concatenar(Lista* A, Lista* B) {
	if (B->inicio == NULL) {
		return;
	}
	if (A->inicio == NULL) {
		A->inicio = B->inicio;
		A->tamanho = B->tamanho;
	}
	else {
		Elemento* fimA = A->inicio;
		while (fimA->prox != NULL) {
			fimA = fimA->prox;
		}
		fimA->prox = B->inicio;
		B->inicio->ant = fimA;
		A->tamanho += B->tamanho;
	}
	B->inicio = NULL;
	B->tamanho = 0;
}

int main() {
	Lista A, B;
	criar(&A);
	criar(&B);

	int opcao, valor;

	do {
		printf("1-Inserir em A\n");
		printf("2-Inserir em B\n");
		printf("3-Mostrar em A\n");
		printf("4-Mostrar em B\n");
		printf("5-Concatenar B em A\n");
		printf("6-SAIR\n");
		printf("Escolha:\n");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Valor para A: \n");
			scanf_s("%d", &valor);
			inserirfim(valor, &A);
			break;

		case 2:
			printf("Valor para B: \n");
			scanf_s("%d", &valor);
			inserirfim(valor, &B);
			break;

		case 3:
			mostrar(&A);
			break;

		case 4:
			mostrar(&B);
			break;

		case 5:
			concatenar(&A, &B);
			printf("CONCATENADO\n");
			break;

		case 6:
			printf("SAINDO\n");
			break;

		default:
			printf("Opcao inv�lida\n");
		}
	} while (opcao != 6);
	return 0;
}
