#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Elemento {
	int valor;
	struct Elemento* ant, * prox;
}Elemento;

typedef struct EDLista {
	Elemento* inicio;
	Elemento* fim;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int inserirordem(int valor, Lista* lista) {
	if (lista == NULL) {
		return 0;
	}
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	no->ant = NULL;
	if (lista->inicio == NULL) {
		lista->inicio = no;
		lista->fim = no;
		lista->tamanho++;
		return 1;
	}
	Elemento* ant = NULL;
	Elemento* atual = lista->inicio;
	while ((atual != NULL) && (atual->valor < valor)) {
		ant = atual;
		atual = atual->prox;
	}
	if (atual == lista->inicio) {
		no->prox = lista->inicio;
		lista->inicio->ant = no;
		lista->inicio = no;
	}
	else if (atual == NULL) {
		no->ant = lista->fim;
		lista->fim->prox = no;
		lista->fim = no;
	}
	else {
		no->prox = atual;
		no->ant = ant;
		ant->prox = no;
		atual->ant = no;
	}

	lista->tamanho++;
	return 1;
}

void mostrar(Lista* lista,const char* nome) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Lista Vazia \n");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

void intercalar(Lista* A, Lista* B, Lista* C) {
	Elemento* pA = A->inicio;
	Elemento* pB = B->inicio;

	while (pA != NULL && pB != NULL) {
		if (pA->valor <= pB->valor) {
			inserirordem(pA->valor, C);
			pA = pA->prox;
		}
		else {
			inserirordem(pB->valor, C);
			pB = pB->prox;
		}
	}
	while (pA != NULL) {
		inserirordem(pA->valor, C);
		pA = pA->prox;
	}
	while (pB != NULL) {
		inserirordem(pB->valor, C);
		pB = pB->prox;
	}

}

int main() {
	Lista A, B, C;
	criar(&A);
	criar(&B);
	criar(&C);

	int opcao, valor;

	do {
		printf("MENU\n");
		printf("1 - Inserir na lista A\n");
		printf("2 - Inserir na lista B\n");
		printf("3 - Mostrar listas A e B\n");
		printf("4 - Intercalar A e B em C\n");
		printf("5 - Mostrar lista C\n");
		printf("6 - Sair\n");
		printf("Escolha: ");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Valor para A: ");
			scanf_s("%d", &valor);
			inserirordem(valor, &A);
			break;
		case 2:
			printf("Valor para B: ");
			scanf_s("%d", &valor);
			inserirordem(valor, &B);
			break;
		case 3:
			mostrar(&A, "Lista A");
			mostrar(&B, "Lista B");
			break;
		case 4:
			intercalar(&A, &B, &C);
			printf("Listas A e B intercaladas em C.\n");
			break;
		case 5:
			mostrar(&C, "Lista C (intercalada)");
			break;
		case 6:
			printf("Saindo...\n");
			break;
		default:
			printf("Op��o invalida.\n");
		}

	} while (opcao != 6);

	return 0;
}