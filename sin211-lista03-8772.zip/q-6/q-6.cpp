#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Elemento {
	int valor;
	struct Elemento* ant, * prox;
}Elemento;

typedef struct EDLista {
	Elemento* inicio;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int inserirordenado(int valor, Lista* lista) {
	if (lista == NULL) return 0;

	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (no == NULL) return 0;
	no->valor = valor;

	if (lista->inicio == NULL) {
		no->prox = NULL;
		no->ant = NULL;
		lista->inicio = no;
	}
	else {
		Elemento* ant = NULL;
		Elemento* atual = lista->inicio;
		while ((atual != NULL) && (atual->valor < valor)) {
			ant = atual;
			atual = atual->prox;
		}
		if (atual == lista->inicio) {
			no->ant = NULL;
			no->prox = lista->inicio;
			lista->inicio->ant = no;
			lista->inicio = no;
		}
		else {
			no->prox = ant->prox;
			no->ant = ant;
			ant->prox = no;
			if (atual != NULL) {
				atual->ant = no;
			}
		}
	}
	lista->tamanho++;
	return 1;
}
int removerordenada(int valor, Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		return 0;
	}
	while ((no != NULL) && (no->valor != valor)) {
		no = no->prox;
	}
	if (no == NULL) {
		return 0;
	}
	if (no->ant == NULL) {
		lista->inicio = no->prox;
	}
	if (no->prox != NULL) {
		no->prox->ant = no->ant;
	}
	free(no);
	lista->tamanho--;
	return 1;
}

int inseririnicio(int valor, Lista* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL) {
		return 0;
	}
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = lista->inicio;
	no->ant = NULL;
	if (lista->inicio!=no) {
		lista->inicio->ant = no;
	}
	lista->inicio = no;
	lista->tamanho++;
	return 1;
}

int removerinicio(Lista* lista) {
	Elemento* no;
	if (lista->inicio == NULL) {
		return 0;
	}
	no = lista->inicio;
	lista->inicio = no->prox;
	if (no->prox != NULL) {
		no->prox->ant = NULL;
	}
	free(no);
	lista->tamanho--;
	return 1;
}

int inserirfim(int valor, Lista* lista) {
	Elemento* aux = lista->inicio, * no = (Elemento*)malloc(sizeof(Elemento));
	if (no == NULL || lista == NULL) {
		return 0;
	}
	no->valor = valor;
	no->prox = NULL;
	if (lista->inicio == NULL) {
		no->ant = NULL;
		lista->inicio = no;
	}
	else {
		while (aux->prox != NULL) {
			aux = aux->prox;
		}
		aux->prox = no;
		no->ant = aux;
	}
	lista->tamanho++;
	return 1;
}

int removerfim(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		return 0;
	}
	while (no->prox != NULL) {
		no = no->prox;
	}
	if (no->ant == NULL) {
		lista->inicio = no->prox;
	}
	else {
		no->ant->prox = NULL;
	}
	free(no);
	lista->tamanho--;
	return 1;
}

int buscar(int valor, Lista* lista) {
	Elemento* no = lista->inicio;
	int posicao = 0, numero;
	if (lista->inicio == NULL) {
		return -1;
	}
	while ((no != NULL) && (no->valor != valor)) {
		no = no->prox;
		posicao++;
	}
	if (no == NULL) {
		return -1;
	}
	else {
		numero = no->valor;
		return posicao;;
	}
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Lista Vazia");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

int main() {
	Lista lista;
	criar(&lista);

	int opcao, valor;

	do {
		printf("MENU\n");
		printf("1-Inserir ordenado\n");
		printf("2-Remover ordenado\n");
		printf("3-Inserir no inicio\n");
		printf("4-Remover no inicio\n");
		printf("5-Inserir no fim\n");
		printf("6-Remover no fim\n");
		printf("7-Buscar valor\n");
		printf("8-Mostrar lista\n");
		printf("9-SAIR\n");
		printf("Escolha \n");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Valor a inserir:\n");
			scanf_s("%d", &valor);
			if (inserirordenado(valor, &lista)) {
				printf("Inserido\n");
			}
			break;

		case 2:
			printf("Valor a remover:\n");
			scanf_s("%d", &valor);
			if (removerordenada(valor, &lista)) {
				printf("Removido\n");
			}
			else {
				printf("Nao encontado\n");
			}
			break;

		case 3:
			printf("Valor a ser inserido:\n");
			scanf_s("%d", &valor);
			inseririnicio(valor, &lista);
			break;

		case 4:
			if (removerinicio(&lista)) {
				printf("Removido\n");
			}
			else {
				printf("Lista Vazia\n");
			}
			break;

		case 5:
			printf("Valor a ser inserido:\n");
			scanf_s("%d", &valor);
			inserirfim(valor, &lista);
			break;

		case 6:
			if (removerfim(&lista)) {
				printf("Removido\n");
			}
			else {
				printf("Lista Vazia\n");
			}
			break;

		case 7:
			printf("Valor a buscar:\n");
			scanf_s("%d", &valor);
			int posicao;
			posicao = buscar(valor, &lista);
			if (posicao != -1) {
				printf("Encontrado na posicao %d\n", posicao);
			}
			else {
				printf("N�o encontrado\n");
			}
			break;

		case 8:
			mostrar(&lista);
			break;

		case 9:
			printf("Saindo\n");
			break;

		default:
			printf("Invalido");
		}
	} while (opcao != 9);
	return 0;
}



