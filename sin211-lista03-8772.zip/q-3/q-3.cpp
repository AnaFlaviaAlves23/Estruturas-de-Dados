#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct elemento {
	int valor;
	struct elemento* prox;
}Elemento;

typedef struct EDLista {
	Elemento* fim;
	int tamaho;
}ListaCircular;

int inserirfim(int valor, ListaCircular* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	if (lista->fim == NULL) {
		lista->fim = no;
		no->prox = no;
	}
	else {
		no->prox = lista->fim->prox;
		lista->fim->prox = no;
		lista->fim = no;
	}
	lista->tamaho++;
	return 1;
}

void mostrar(ListaCircular* lista) {
	Elemento* no;
	if (lista->fim == NULL) {
		printf("Vazia");
	}
	else {
		no = lista->fim->prox;
		while (no != lista->fim) {
			printf("%d", no->valor);
			no = no->prox;
		}
		if ((no == lista->fim) && (no != NULL)) {
			printf("%d", no->valor);
		}
	}
}

Elemento* remover_todos(Elemento* inicio, int valor) {
	if (inicio == NULL) {
		return NULL;
	}
	Elemento* atual = inicio;
	Elemento* anterior = NULL;
	int mudou_inicio = 0;
	do {
		Elemento* proximo = atual->prox;
		if (atual->valor == valor) {
			if (atual == proximo) {
				free(atual);
				return NULL;
			}
			if (anterior != NULL) {
				anterior->prox = atual->prox;
				if (atual == inicio) {
					inicio = atual->prox;
					mudou_inicio = 1;
				}
				free(atual);
				atual = anterior;
			}
			else {
				Elemento* fim = inicio;
				while (fim->prox != inicio) {
					fim = fim->prox;
				}
				fim->prox = atual->prox;
				inicio = atual->prox;
				free(atual);
				atual = fim;
				mudou_inicio = 1;
			}
		}
		else {
			anterior = atual;
		}
		atual = atual->prox;
	} while (atual != inicio || mudou_inicio);
	return inicio;
}

int main() {
	ListaCircular lista;
	lista.fim = NULL;
	lista.tamaho = 0;
	int opcao, valor;

	do {
		printf("1 - Inserir valor\n");
		printf("2 - Remover todos com valor X\n");
		printf("3 - Mostrar lista\n");
		printf("4 - Sair\n");
		printf("Escolha: ");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Valor: ");
			scanf_s("%d", &valor);
			inserirfim(valor, &lista);
			break;

		case 2:
			printf("Valor a remover: ");
			scanf_s("%d", &valor);
			if (lista.fim != NULL) {
				Elemento* novo_inicio = remover_todos(lista.fim->prox, valor);
				if (novo_inicio == NULL) {
					lista.fim = NULL;
					lista.tamaho = 0;
				}
				else {
					Elemento* temp = novo_inicio;
					do {
						temp = temp->prox;
					} while (temp->prox != novo_inicio);
					lista.fim = temp;
				}
			}
			break;

		case 3:
			mostrar(&lista);
			break;

		case 4:
			printf("Saindo\n");
			break;

		default:
			printf("Op��o invalida.\n");
		}
	} while (opcao != 0);

	return 0;
}