#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct elemento {
	int valor;
	struct elemento* prox;
}Elemento;

typedef struct EDLista {
	Elemento* fim;
	int tamanho;
}ListaCircular;

int inserirfim(char valor, ListaCircular* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	if (lista->fim == NULL) {
		lista->fim = no;
		no->prox = no;
	}
	else {
		no->prox = lista->fim->prox;
		lista->fim->prox = no;
		lista->fim = no;
	}
	lista->tamanho++;
	return 1;
}

void mostrar(ListaCircular* lista) {
	Elemento* no;
	if (lista->fim == NULL) {
		printf("Vazia");
	}
	else {
		no = lista->fim->prox;
		while (no != lista->fim) {
			printf("%d", no->valor);
			no = no->prox;
		}
		if ((no == lista->fim) && (no != NULL)) {
			printf("%d", no->valor);
		}
	}
}

void concatenar(ListaCircular* A, ListaCircular* B) {
	if (B->fim == NULL) {
		return;
	}
	if (A->fim == NULL) {
		A->fim = B->fim;
		A->tamanho = B->tamanho;
		return;
	}
	Elemento* inicioA = A->fim->prox;
	Elemento* inicioB = B->fim->prox;
	A->fim->prox = inicioB;
	B->fim->prox = inicioA;
	A->fim = B->fim;
	A->tamanho += B->tamanho;
	B->fim = NULL;
	B->tamanho = 0;
}

int main() {
	ListaCircular A, B;
	A.fim = NULL; A.tamanho = 0;
	B.fim = NULL; B.tamanho = 0;

	int opcao, valor;

	do {
		printf("MENU\n");
		printf("1 - Inserir na lista A\n");
		printf("2 - Inserir na lista B\n");
		printf("3 - Mostrar lista A\n");
		printf("4 - Mostrar lista B\n");
		printf("5 - Concatenar B em A\n");
		printf("6 - Sair\n");
		printf("Escolha: ");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Valor para A: ");
			scanf_s("%d", &valor);
			inserirfim(valor, &A);
			break;
		case 2:
			printf("Valor para B: ");
			scanf_s("%d", &valor);
			inserirfim(valor, &B);
			break;
		case 3:
			printf("Lista A: ");
			mostrar(&A);
			break;
		case 4:
			printf("Lista B: ");
			mostrar(&B);
			break;
		case 5:
			concatenar(&A, &B);
			printf("Listas concatenadas!\n");
			break;
		case 6:
			printf("Saindo\n");
			break;
		default:
			printf("Opcao invalida\n");
		}
	} while (opcao != 6);

	return 0;
}


