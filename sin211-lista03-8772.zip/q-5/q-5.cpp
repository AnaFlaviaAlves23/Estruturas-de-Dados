#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct elemento {
	int valor;
	struct elemento* prox;
}Elemento;

typedef struct EDLista {
	Elemento* fim;
	int tamanho;
}ListaCircular;

int inserirordenada(int valor, ListaCircular* lista) {
	Elemento* no, * ant, * atual;
	if (lista == NULL) {
		return 0;
	}
	no = (Elemento*)malloc(sizeof(Elemento));
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	if (lista->fim == NULL) {
		lista->fim = no;
		no->prox = no;
	}
	else {
		ant = lista->fim;
		atual = lista->fim->prox;
		while (atual != lista->fim && (valor > atual->valor)) {
			ant = atual;
			atual = atual->prox;
		}
		if ((atual == lista->fim) && (valor < lista->fim->valor)) {
			no->prox = lista->fim;
			lista->fim->prox = no;
		}
		else if (atual == lista->fim) {
			no->prox = lista->fim->prox;
			lista->fim = no;
		}
		else {
			ant->prox = no;
			no->prox = atual;
		}
	}
	lista->tamanho++;
	return 1;
}

void mostrar(ListaCircular* lista) {
	Elemento* no;
	if (lista->fim == NULL) {
		printf("Vazia");
	}
	else {
		no = lista->fim->prox;
		while (no != lista->fim) {
			printf("%d", no->valor);
			no = no->prox;
		}
		if ((no == lista->fim) && (no != NULL)) {
			printf("%d", no->valor);
		}
	}
}

void intercalar_ordenado(ListaCircular* A, ListaCircular* B, ListaCircular* C) {
	if (A->fim == NULL && B->fim == NULL) {
		return;
	}
	Elemento* atualA = (A->fim) ? A->fim->prox : NULL;
	Elemento* atualB = (B->fim) ? B->fim->prox : NULL;

	int voltasA = (atualA == NULL) ? 0 : 1;
	int voltasB = (atualB == NULL) ? 0 : 1;

	while (voltasA || voltasB) {
		if (voltasA && (!voltasB || atualA->valor <= atualB->valor)) {
			inserirordenada(atualA->valor, C);
			atualA = atualA->prox;
			if (atualA == A->fim->prox)voltasA = 0;
		}
		else if (voltasB) {
			inserirordenada(atualB->valor, C);
			atualB = atualB->prox;
			if (atualB == B->fim->prox)voltasB = 0;
		}
	}
}

int main() {
	ListaCircular A = { NULL, 0 };
	ListaCircular B = { NULL, 0 };
	ListaCircular C = { NULL, 0 };

	int opcao, valor;

	do {
		printf("MENU\n");
		printf("1 - Inserir ordenado na lista A\n");
		printf("2 - Inserir ordenado na lista B\n");
		printf("3 - Mostrar lista A\n");
		printf("4 - Mostrar lista B\n");
		printf("5 - Intercalar A e B em C\n");
		printf("6 - Mostrar lista C\n");
		printf("7 - Sair\n");
		printf("Escolha: ");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Valor para A: ");
			scanf_s("%d", &valor);
			inserirordenada(valor, &A);
			break;
		case 2:
			printf("Valor para B: ");
			scanf_s("%d", &valor);
			inserirordenada(valor, &B);
			break;
		case 3:
			printf("Lista A: ");
			mostrar(&A);
			break;
		case 4:
			printf("Lista B: ");
			mostrar(&B);
			break;
		case 5:
			intercalar_ordenado(&A, &B, &C);
			printf("Listas A e B intercaladas em C!\n");
			break;
		case 6:
			printf("Lista C: ");
			mostrar(&C);
			break;
		case 7:
			printf("Saindo\n");
			break;
		default:
			printf("Opcao invalida\n");
		}
	} while (opcao != 7);

	return 0;
}