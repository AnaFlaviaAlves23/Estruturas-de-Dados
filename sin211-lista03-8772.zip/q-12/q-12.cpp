#include <stdio.h>
#include <stdlib.h>
#include<string.h>

typedef struct No {
    int valor;
    struct No* esq;
    struct No* dir;
} No;

int inserir(No** raiz, int valor) {
    if (raiz == NULL) return 0;
    No* novo = (No*)malloc(sizeof(No));
    if (novo == NULL) return 0;
    novo->valor = valor;
    novo->esq = NULL;
    novo->dir = NULL;
    if (*raiz == NULL) {
        *raiz = novo;
        return 1;
    }
    No* atual = *raiz;
    No* anterior = NULL;
    while (atual != NULL) {
        anterior = atual;
        if (valor == atual->valor) {
            free(novo);
            return 0;
        }
        if (valor < atual->valor) {
            atual = atual->esq;
        }
        else {
            atual = atual->dir;
        }
    }
    if (valor < anterior->valor) {
        anterior->esq = novo;
    }
    else {
        anterior->dir = novo;
    }
    return 1;
}

No* menorDireita(No* raiz) {
    No* atual = raiz;
    while (atual->esq != NULL) {
        atual = atual->esq;
    }
    return atual;
}

No* remover(No* raiz, int valor) {
    if (raiz == NULL) return NULL;

    if (valor < raiz->valor) {
        raiz->esq = remover(raiz->esq, valor);
    }
    else if (valor > raiz->valor) {
        raiz->dir = remover(raiz->dir, valor);
    }
    else {
        if (raiz->esq == NULL) {
            No* temp = raiz->dir;
            free(raiz);
            return temp;
        }
        else if (raiz->dir == NULL) {
            No* temp = raiz->esq;
            free(raiz);
            return temp;
        }
        No* temp = menorDireita(raiz->dir);
        raiz->valor = temp->valor;
        raiz->dir = remover(raiz->dir, temp->valor);
    }
    return raiz;
}


int buscar(No* raiz, int valor) {
    if (raiz == NULL) {
        return 0;
    }
    struct No* atual = *raiz;
    while (atual != NULL) {
        if (valor == raiz->valor) {
            printf("Consulta:%d encontrada", atual->valor);
            return 1;
        }
        if (valor < raiz->valor) {
            atual = atual->dir;
        }
        else {
            atual = atual->esq;
        }
        printf("Consulta: O valor %d n�o foi encontrado", valor);
    }
     
}

int contarNos(No* raiz) {
    if (raiz == NULL) return 0;
    return 1 + contarNos(raiz->esq) + contarNos(raiz->dir);
}

int contarNaoFolhas(No* raiz) {
    if (raiz == NULL || (raiz->esq == NULL && raiz->dir == NULL)) return 0;
    return 1 + contarNaoFolhas(raiz->esq) + contarNaoFolhas(raiz->dir);
}

int maiorValor(No* raiz) {
    if (raiz == NULL) return -1;
    while (raiz->dir != NULL) {
        raiz = raiz->dir;
    }
    return raiz->valor;
}


void preOrdem(No* raiz) {
    if (raiz != NULL) {
        return;
    }
    if(*raiz!=NULL){
        printf("\n %d",(*raiz)->valor);
        preOrdem(&((*raiz)->esq));
        preOrdem(&((*raiz)->dir));
    }
}

void emOrdem(No* raiz) {
    if (raiz != NULL) {
        return;
    }
    if(*raiz!=NULL){
        emOrdem(&((*raiz)->esq));
        printf("\n,%d", (*raiz)->valor);
        emOrdem(&((*raiz)->dir);
    }
}


void posOrdem(No* raiz) {
    if (raiz != NULL) {
        return;
    }
    if(*raiz != NULL){
        posOrdem(&((*raiz->esq));
        posOrdem(&((*raiz->dir));
        printf("\n %d", (*raiz)->valor);
    }
}

int main() {
    No* raiz = NULL;
    int opcao, valor;

    do {
        printf("\n--- MENU �RVORE ---\n");
        printf("1 - Inserir\n");
        printf("2 - Remover\n");
        printf("3 - Buscar\n");
        printf("4 - Contar n�s\n");
        printf("5 - Contar n�s n�o folhas\n");
        printf("6 - Maior valor\n");
        printf("7 - Pr�-ordem\n");
        printf("8 - Em-ordem\n");
        printf("9 - P�s-ordem\n");
        printf("0 - Sair\n");
        printf("Escolha: ");
        scanf("%d", &opcao);

        switch (opcao) {
        case 1:
            printf("Digite o valor: ");
            scanf("%d", &valor);
            if (inserir(&raiz, valor)) printf("Inserido!\n");
            else printf("J� existe!\n");
            break;

        case 2:
            printf("Digite o valor a remover: ");
            scanf("%d", &valor);
            raiz = remover(raiz, valor);
            printf("Removido (se existia).\n");
            break;

        case 3:
            printf("Digite o valor a buscar: ");
            scanf("%d", &valor);
            printf(buscar(raiz, valor) ? "Encontrado\n" : "N�o encontrado\n");
            break;

        case 4:
            printf("Total de n�s: %d\n", contarNos(raiz));
            break;

        case 5:
            printf("N�s n�o folhas: %d\n", contarNaoFolhas(raiz));
            break;

        case 6:
            printf("Maior valor: %d\n", maiorValor(raiz));
            break;

        case 7:
            printf("Pr�-ordem: ");
            preOrdem(raiz);
            printf("\n");
            break;

        case 8:
            printf("Em-ordem: ");
            emOrdem(raiz);
            printf("\n");
            break;

        case 9:
            printf("P�s-ordem: ");
            posOrdem(raiz);
            printf("\n");
            break;

        case 0:
            printf("Saindo...\n");
            break;

        default:
            printf("Op��o inv�lida.\n");
        }

    } while (opcao != 0);

    return 0;
}
