#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Elemento {
	int valor;
	struct Elemento* ant, * prox;
}Elemento;

typedef struct EDLista {
	Elemento* inicio;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int inserirordem(int valor, Lista* lista) {
	Elemento* no;
	if (lista == NULL) {
		return 0;
	}
	no = (Elemento*)malloc(sizeof(Elemento));
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	if (lista->inicio == NULL) {
		no->prox = NULL;
		no->ant = NULL;
		lista->inicio = no;
		
		return 1;
	}
	else {
		Elemento* ant = NULL;
		Elemento* atual = lista->inicio;
		while ((atual != NULL) && (atual->valor < valor)) {
			ant = atual;
			atual = atual->prox;
		}
		if (atual == lista->inicio) {
			no->ant = NULL;
			lista->inicio->ant = no;
			no->prox = lista->inicio;
		}
		else {
			no->prox = atual;
			no->ant = ant;
			ant->prox = no;
			if (atual != NULL) {
				atual->ant = no;
			}
		}
		
		return 1;
	}
}

void mostrar(Lista* lista,const char* nome) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Lista Vazia\n");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

void dividir_par_impar(Lista* C, Lista* A, Lista* B) {
	Elemento* atual = C->inicio;
	while (atual != NULL) {
		if (atual->valor % 2 == 0) {
			inserirordem(atual->valor, A);
		}
		else {
			inserirordem(atual->valor, B);
		}
		atual = atual->prox;
	}
}

int main() {
	Lista C, A, B;
	criar(&C);
	criar(&A);
	criar(&B);

	int opcao, valor;

	do {
		printf("MENU\n");
		printf("1-Inserir na lista C (ordenado) \n");
		printf("2-Mostrar lista C \n");
		printf("3-Dividir lista C em A (pares) e B (impares) \n");
		printf("4-Mostrar listas A e B \n");
		printf("5-SAIR \n");
		printf("Escolha: \n");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Digite o valor: \n");
			scanf_s("%d", &valor);
			inserirordem(valor, &C);
			break;

		case 2:
			mostrar(&C, "Lista C");
			break;

		case 3:
			dividir_par_impar(&C, &A, &B);
			printf("Listas A e B criadas a partir de C \n");
			break;

		case 4:
			mostrar(&A, "Lista A(pares)");
			mostrar(&A, "Lista B(impares)");
			break;

		case 5:
			printf("Saindo\n");
			break;

		default:
			printf("Opcao invalida \n");

		}

	} while (opcao != 5);

	return 0;
}