#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Elemento {
	int valor;
	struct Elemento* ant, * prox;
}Elemento;

typedef struct EDLista {
	Elemento* inicio;
	Elemento* fim;
	int tamanho;
}Lista;

void criar(Lista* lista) {
	lista->inicio = NULL;
	lista->tamanho = 0;
}

int inserirordenado(int valor, Lista* lista) {
	Elemento* no;
	if (lista == NULL) {
		return 0;
	}
	no = (Elemento*)malloc(sizeof(Elemento));
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	if (lista->inicio == NULL) {
		no->prox = NULL;
		no->ant = NULL;
		lista->inicio = no;
		return 1;
	}
	else {
		Elemento* ant = NULL;
		Elemento* atual = lista->inicio;
		while ((atual != NULL) && (atual->valor < valor)) {
			ant = atual;
			atual = atual->prox;
		}
		if (atual == lista->inicio) {
			no->ant = NULL;
			lista->inicio->ant = no;
			no->prox = lista->inicio;
		}
		else {
			no->prox = ant->prox;
			no->ant = ant;
			ant->prox = no;
			if (atual != NULL) {
				atual->ant = no;
			}
		}
		return 1;
	}
}

void mostrar(Lista* lista) {
	Elemento* no = lista->inicio;
	if (lista->inicio == NULL) {
		printf("Lista Vazia\n");
	}
	else {
		printf("\n");
		while (no != NULL) {
			printf("%d", no->valor);
			no = no->prox;
		}
	}
}

void mostrar_reverso(Lista* lista) {
	Elemento* atual = lista->fim;
	printf("Lista reversa: ");
	while (atual != NULL) {
		printf("%d ", atual->valor);
		atual = atual->ant;
	}
	printf("\n");
}

int main() {
	Lista lista;
	criar(&lista);

	int opcao, valor;

	do {
		printf("MENU\n");
		printf("1-Inserir ordenado\n");
		printf("2-Mostrar lista direta\n");
		printf("3-Mostrar lista reversa\n");
		printf("4-Sair\n");
		printf("Escolha: ");
		scanf_s("%d",&opcao);

		switch (opcao) {
		case 1:
			printf("Digite um valor: \n");
			scanf_s("%d", &valor);
			inserirordenado(valor, &lista);
			break;

		case 2: 
			mostrar(&lista);
			break;

		case 3:
			mostrar_reverso(&lista);
			break;

		case 4:
			printf("Saindo \n");
			break;

		default:
			printf("INVALIDO\n");

		}

	} while (opcao != 4);

	return 0;
}