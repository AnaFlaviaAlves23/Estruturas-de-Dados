#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct elemento {
	int valor;
	struct elemento* prox;
}Elemento;

typedef struct EDLista {
	Elemento* fim;
	int tamaho;
}ListaCircular;

int inserirfim(int valor, ListaCircular* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	if (lista->fim == NULL) {
		lista->fim = no;
		no->prox = no;
	}
	else {
		no->prox = lista->fim->prox;
		lista->fim->prox = no;
		lista->fim = no;
	}
	lista->tamaho++;
	return 1;
}

void mostrar(ListaCircular* lista) {
	Elemento* no;
	if (lista->fim == NULL) {
		printf("Vazia\n");
	}
	else {
		no = lista->fim->prox;
		while (no != lista->fim) {
			printf("%d", no->valor);
			no = no->prox;
		}
		if ((no == lista->fim) && (no != NULL)) {
			printf("%d", no->valor);
		}
	}
}

int contar_maiores(ListaCircular* lista, int N) {
	if (lista == NULL || lista->fim == NULL) {
		return 0;
	}
	int cont = 0;
	Elemento* atual = lista->fim->prox;
	do {
		if (atual->valor > N) {
			cont++;
		}
		atual = atual->prox;
	} while (atual != lista->fim->prox);
	return cont;
}

int main() {
	ListaCircular lista;
	lista.fim = NULL;
	lista.tamaho = 0;
	int opcao, valor, N;
	do {
		printf("Menu\n");
		printf("1-Inserir Valor\n");
		printf("2-Mostrar Lista");
		printf("3-Contar elementos maiores que N\n");
		printf("4-SAIR");
		scanf_s("%d", &opcao);

		switch (opcao) {
		case 1:
			printf("Digite um numero inteiro");
			scanf_s("%d", &valor);
			if (inserirfim(valor, &lista)) {
				printf("Inserido com Sucesso\n");
			}
			else {
				printf("Erro ao inserir\n");
			}
			break;

		case 2:
			printf("Lista Atual\n");
			mostrar(&lista);
			break;

		case 3:
			printf("Digite o valor de N: \n");
			scanf_s("%d", &N);
			printf("Quantidade de elementos maiores que %d: %d\n", N, contar_maiores(&lista, N));
			break;

		case 4:
			printf("Saindo\n");
			break;

		default:
			printf("INVALIDO\n");
		}
	} while (opcao != 0);
	
	return 0;
}