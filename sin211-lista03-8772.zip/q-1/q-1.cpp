#include<stdio.h>
#include<stdlib.h>

typedef struct elemento {
	int valor;
	struct elemento* prox;
}Elemento;

typedef struct EDLista {
	Elemento* fim;
	int tamaho;
}ListaCircular;

int inserirordem(int valor, ListaCircular* lista) {
	Elemento* no, * ant, * atual;
	if (lista == NULL) {
		return 0;
	}
	no = (Elemento*)malloc(sizeof(Elemento));
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	if (lista->fim == NULL) {
		lista->fim = no;
		no->prox = no;
	}
	else {
		ant = lista->fim;
		atual = lista->fim->prox;
		while (atual != lista->fim && (valor > atual->valor)) {
			ant = atual;
			atual = atual->prox;
		}
		if ((atual == lista->fim) && (valor < lista->fim->valor)) {
			no->prox = lista->fim;
			lista->fim->prox = no;
		}
		else if (atual == lista->fim) {
			no->prox = lista->fim->prox;
			lista->fim = no;
		}
		else {
			ant->prox = no;
			no->prox = atual;
		}
	}
	lista->tamaho++;
	return 1;
}

int removerordem(int valor, ListaCircular* lista) {
	Elemento* ant, * atual, * no = lista->fim;
	if (lista->fim == NULL) {
		return 0;
	}
	ant = lista->fim;
	no = lista->fim->prox;
	while (no!= lista->fim && (valor != no->valor)) {
		ant = no;
		no = no->prox;
	}
	if ((no == lista->fim) && (valor != no->valor)) {
		return 0;
	}
	if ((no == lista->fim) && (valor == no->valor)) {
		if (lista->fim == lista->fim->prox) {
			lista->fim = lista->fim->prox = NULL;
		}
		else {
			ant->prox = lista->fim->prox;
			lista->fim = ant;
		}
	}
	else {
		ant->prox = no->prox;
	}
	lista->tamaho--;
	free(no);
	return 1;
}

int inseririnicio(int valor, ListaCircular* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL) {
		return 0;
	}
	if (no == NULL) {
		return 0;
	}
	no->valor = valor;
	if (lista->fim == NULL) {
		lista->fim = no;
		lista->fim->prox = no;
	}
	else {
		no->prox = lista->fim->prox;
		lista->fim->prox = no;
	}
	lista->tamaho++;
	return 1;
}

int removerinicio(ListaCircular* lista) {
	Elemento* no = lista->fim;
	if (lista->fim == NULL) {
		return 0;
	}
	if (lista->fim == lista->fim->prox) {
		free(no);
		lista->fim = NULL;
		return 1;
	}
	no = lista->fim->prox;
	lista->fim->prox = no->prox;
	free(no);
	lista->tamaho--;
	return 1;
}

int inserirfim(int valor, ListaCircular* lista) {
	Elemento* no = (Elemento*)malloc(sizeof(Elemento));
	if (lista == NULL || no == NULL) {
		return 0;
	}
	no->valor = valor;
	if (lista->fim == NULL) {
		lista->fim = no;
		no->prox = no;
	}
	else {
		no->prox = lista->fim->prox;
		lista->fim->prox = no;
		lista->fim = no;
	}
	lista->tamaho++;
	return 1;
}

int removerfim(ListaCircular* lista) {
	Elemento* no, * ant;
	if (lista->fim == NULL) {
		return 0;
	}
	if (lista->fim == lista->fim->prox) {
		no = lista->fim;
		lista->fim = NULL;
		free(no);
		return 1;
	}
	ant = lista->fim->prox;
	while (ant->prox != lista->fim) {
		ant = ant->prox;
	}
	no = ant->prox;
	ant->prox = no->prox;
	lista->fim = ant;
	free(no);
	lista->tamaho--;
	return 1;
}

void mostrar(ListaCircular* lista) {
	Elemento* no;
	if (lista->fim == NULL) {
		printf("Vazia");
	}
	else {
		no = lista->fim->prox;
		while (no != lista->fim) {
			printf("%d", no->valor);
			no = no->prox;
		}
		if ((no == lista->fim) && (no != NULL)) {
			printf("%d", no->valor);
		}
	}
}

int buscar(int valor, ListaCircular* lista) {
	Elemento* ant, * no = lista->fim->prox;
	int pos = 0, numero;
	if (lista->fim == NULL) {
		return -1;
	}
	while ((no != lista->fim) && (no->valor != valor)) {
		no = no->prox;
		pos++;
	}
	if (no->valor == valor) {
		numero = no->valor;
		return pos;
	}
	return -1;
}

int main() {
	ListaCircular lista;
	lista.fim = NULL;
	lista.tamaho = 0;

	int opcao, valor;

	do {
		printf("MENU\n");
		printf("1-Inserir Ordenado\n");
		printf("2-Remover Ordenado\n");
		printf("3-Inserir Inicio\n");
		printf("4-Remover Inicio\n");
		printf("5-Inserir Fim\n");
		printf("6-Remover Fim\n");
		printf("7-Pesquisar Valor\n");
		printf("8-Exibir Lista\n");
		printf("9-Sair\n");
		printf("Escolha:\n");
		scanf_s("%d",&opcao);

		switch (opcao) {
		case 1:
			printf("Digite o valor a inserir ordenado");
			scanf_s("%d", &valor);
			if (inserirordem(valor, &lista)) {
				printf("Inserido com sucesso\n");
			}
			else {
				printf("Erro ao inserir\n");
			}
			break;

		case 2:
			printf("Digite o valor a remover");
			scanf_s("%d", &valor);
			if (removerordem(valor, &lista)) {
				printf("Removido com sucesso\n");
			}
			else {
				printf("Valor n�o encontrado\n");
			}
			break;

		case 3:
			printf("Digite o valor a ser inserido no inicio");
			scanf_s("%d", &valor);
			if (inseririnicio(valor, &lista)) {
				printf("Inserido  com sucesso\n");
			}
			else {
				printf("Erro ao inserir\n");
			}
			break;

		case 4:
			if (removerinicio(&lista)) {
				printf("Removido com sucesso\n");
			}
			else {
				printf("Lista vazia\n");
			}
			break;

		case 5:
			printf("Digite o valor a ser inserido no fim");
			scanf_s("%d", &valor);
			if (inserirfim(valor, &lista)) {
				printf("Inserido com sucesso\n");
			}
			else {
				printf("Erro ao inserir\n");
			}
			break;

		case 6:
			if (removerfim(&lista)) {
				printf("Removido com sucesso\n");
			}
			else {
				printf("Lista vazia\n");
			}
			break;

		case 7:
			printf("Digite o valor a ser pesquisado");
			scanf_s("%d", &valor);
			if (buscar(valor,&lista)) {
				printf("Valor encontrado na lista\n");
			}
			else {
				printf("Valor n�o encontrado\n");
			}
			break;

		case 8:
			printf("Lista atual");
			mostrar(&lista);
			break;

		case 9:
			printf("Saindo");
			break;

		default:
			printf("INVALIDO");


		}
	}while (opcao != 0);
}
